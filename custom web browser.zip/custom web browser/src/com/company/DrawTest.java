package com.company;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;

import javax.swing.JComponent;
import javax.swing.JFrame;

public class DrawTest{

    public static MyCanvas canvas;
    public static JFrame jf;
    public static boolean allow_drawing;

    public static void main() {
        jf = new JFrame("Marceldobehere's CustomWeb-Browser");
        Container cp = jf.getContentPane();
        allow_drawing = false;
        JTextField textField = new JTextField();

        textField.addKeyListener(new Keychecker());
        textField.setFocusTraversalKeysEnabled(false);

        cp.add(textField);

        canvas = new MyCanvas();
        cp.add(canvas);
        jf.setSize(1280, 720);
        jf.setVisible(true);
        jf.setResizable(true);
        jf.setMinimumSize(new Dimension(1024,576));
        canvas.toWrite = "";

        // Set to exit on close
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}

class Keychecker extends KeyAdapter {

    @Override
    public void keyPressed(KeyEvent event) {

        char ch = event.getKeyChar();
        if (event.getKeyCode() == 16)
        {
            return;
        }
        if (event.getKeyCode() == 27)
        {
            DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;
            System.out.println("Escape Pressed");
            DrawTest.canvas.toWrite = "";
            DrawTest.canvas.update();
            return;
        }

        if (DrawTest.canvas.selectedThing == MyCanvas.selectedthings.none)
        {

        }
        else if (DrawTest.canvas.selectedThing == MyCanvas.selectedthings.search_bar)
        {
            if (event.getKeyCode() == 8) // Backspace
            {
                if (Main.currentURL.length() != 0)
                {
                    Main.currentURL = Main.currentURL.substring(0,Main.currentURL.length() - 1);
                    DrawTest.canvas.update();
                }
                return;
            }
            else if (event.getKeyCode() == KeyEvent.VK_TAB) // Tab
            {
                Main.currentURL = "";
                DrawTest.canvas.update();
                return;
            }
            else if (event.getKeyCode() == 10) // Enter
            {
                Main.currentURLIndex = Main.allURLs.size() - 1;
                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;
                Main.currentURLIndex = -1;

                FileHandler.loadWebsiteFromURL();

                DrawTest.canvas.update();
                return;
            }


                //System.out.println(ch);
            Main.currentURL += ch;

        }

        DrawTest.canvas.update();
    }

}
