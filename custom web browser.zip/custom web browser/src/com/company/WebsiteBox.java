package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;

public class WebsiteBox
{
    public String x_position;
    public String y_position;
    public String z_position;
    public String width;
    public String height;

    public String id;
    public String text;
    public String image;

    public String oldImage;
    public Image bufferedImage;

    public boolean background_transparent;
    public String background_color;
    public boolean border_shown;
    public String border_thickness;
    public String border_color;
    public String font_name;
    public String font_size;
    public String font_color;
    public boolean box_shown;


    public WebsiteBox()
    {
        x_position = "0";
        y_position = "0";
        z_position = "0";
        height = "1";
        width = "1";

        id = "";
        text = "";
        image = "";

        background_transparent = true;
        background_color = "#000000";
        border_shown = false;
        border_thickness = "1";
        border_color = "#EEEEFF";
        font_name = "Bahnschrift";
        font_size = "20";
        font_color = "#E0E0FF";
        box_shown = true;

        oldImage = "";
        bufferedImage = DrawTest.canvas.iconmap.get(MyCanvas.icon.temp_image);
    }



}
