package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static String defaultPort;
    public static List<String> allURLs;
    public static int currentURLIndex;
    public static String currentURL;
    public static boolean isCurrentURLInternal;

    public static void main(String[] args) {
        System.out.println("- Starting Webbrowser test");
        defaultPort = "1234";
        allURLs = new ArrayList<String>();
        currentURLIndex = -1;



        System.out.println("- Initialising Drawing Area");
        DrawTest.main();

        // TO DO:
        // MAKE THE SCRIPTING LANGUAGE (MAKE IT EVENT BASED)
        // ADD A HOME BUTTON

        // ADD MORE DOCUMENTATION
        // ADD A SETTINGS PAGE
        // ADD A CONFIG FILE
        // ADD BOOKMARKS

        // MAKE A GITHUB REPOs

        // LIMIT THE URL SIZE AND SHORTEN IF NESSESCARY
        // ADD A FULLSCREEN BUTTON OR F11 that also makes the top bar dissapear.

        // MAKE A LOGO
        // POTENTIALLY ADD VIDEO / SOUND SUPPORT
        // POTENTIALLY MAKE A HTML/CSS CONVERTER


        System.out.println("- Starting Main TCP Thread");
        WebsiteInterpreter.initialise();

        Main.currentURL = "!internals/home_page/roml/main.roml";
        FileHandler.loadWebsiteFromURL();


        System.out.println("- Loading Debug Page");
        currentURLIndex = -1;


        System.out.println("- Drawing Website Frame");
        DrawTest.allow_drawing = true;


        System.out.println("- Starting Drawing Loop");
        while (true)
        {
            DrawTest.canvas.update();

            try
            {
                Thread.sleep(25);
            }
            catch(InterruptedException ex)
            {
                Thread.currentThread().interrupt();
            }
        }
    }
}

/*
class MainTCPThread extends Thread {
    private Thread t;
    private String threadName;
    public boolean error;
    public String url;
    public boolean exit;
    public boolean threadexit;
    public boolean isInternal;
    public TCP_Client mainclienttest;



    MainTCPThread(String name, String url) {
        threadName = name;
        error = false;
        this.url = url;
        exit = false;
        threadexit = false;
        mainclienttest = null;
        //System.out.println("- Creating " +  threadName );
    }

    public void run() {

        {
            while (true)
            {
                if (!exit)
                {
                    if (url.length() != 0) {
                        if (url.charAt(0) == '!') {
                            exit = true;
                            // "!internals/debug_page/roml/main.roml"
                            // to
                            // "data/internal/debug_page/roml/main.roml"

                            StringBuilder newUrl = new StringBuilder();

                            if (url.indexOf('/') == -1) {
                                System.out.println("- Error establishing Connection.");
                                //mainclienttest.close();
                                error = true;
                                url = "!internals/page_not_found/roml/main.roml";
                                exit = false;
                                continue;
                            }


                            {
                                if (!url.endsWith(".roml") && !url.endsWith("/")) {
                                    url += ".roml";
                                }

                                if (!url.endsWith(".roml") && url.endsWith("/")) {
                                    url += "main.roml";
                                }
                            }









                            int indexOfName = url.indexOf('/');
                            String mainFolder = url.substring(1, indexOfName);

                            System.out.println("Main Folder: " + mainFolder);

                            if (mainFolder.equals("internals"))
                                newUrl.append("data/internal/");
                            else
                                continue;

                            newUrl.append(url.substring(indexOfName + 1, url.length()));

                            isInternal = true;
                            WebsiteInterpreter.LoadFile(newUrl.toString());


                            while (!threadexit) {

                                try {
                                    for (int i = 0; i < 50 && (!threadexit); i++) {
                                        Thread.sleep(100);
                                    }
                                } catch (InterruptedException e) {
                                    //e.printStackTrace();
                                }
                                System.out.println("Exit?: " + !threadexit);
                            }

                            System.out.println("- Exiting loop.");

                            exit = false;
                            threadexit = false;


                        } else {
                            exit = true;

                            String ip = "localhost";
                            String port = "1234";
                            String url2 = "";


                            if (url.indexOf(':') == -1 && url.indexOf('/') == -1 && url.indexOf('.') == -1) {
                                url += ":" + Main.defaultPort + "/roml/main.roml";
                            }

                            if (url.indexOf(':') == -1 && url.indexOf('/') == -1) {
                                System.out.println("- Error establishing Connection.");
                                //mainclienttest.close();
                                error = true;
                                url = "!internals/page_not_found/roml/main.roml";
                                exit = false;
                                continue;
                            }

                            if (url.indexOf(':') == -1 && url.indexOf('/') != -1) {
                                url = url.substring(0,url.indexOf('/')) + ":" + Main.defaultPort + url.substring(url.indexOf('/'));
                            }

                            if (url.indexOf('/') == -1) {
                                url += "/roml/main.roml";
                            }

                            if (!url.endsWith(".roml") && !url.endsWith("/")) {
                                url += ".roml";
                            }

                            if (!url.endsWith(".roml") && url.endsWith("/")) {
                                url += "main.roml";
                            }

                            //"localhost:1234/roml/main.roml"
                            ip = url.substring(0, url.indexOf(':'));
                            port = url.substring(url.indexOf(':') + 1, url.indexOf('/'));

                            mainclienttest = new TCP_Client(ip, Integer.parseInt(port));
                            System.out.println("socket?: " + mainclienttest.success);
                            if (!mainclienttest.success) {
                                System.out.println("- Error establishing Connection.");
                                //mainclienttest.close();
                                error = true;
                                url = "!internals/server_not_found/roml/main.roml";
                                exit = false;
                                continue;
                            }


                            System.out.println("test ping: " + mainclienttest.ping());

                            System.out.println("Downloading File: " + url);

                            url2 = url.substring(url.indexOf('/') + 1, url.length());

                            String tempURL = mainclienttest.getFilePathOfServerURL(url2);

                            if (tempURL.equals("")) {
                                System.out.println("- Error getting File.");
                                //mainclienttest.close();
                                error = true;
                                url = "!internals/page_not_found/roml/main.roml";
                                exit = false;
                                continue;
                            }

                            System.out.println("Filepath of downloaded file: " + tempURL);
                            isInternal = false;
                            WebsiteInterpreter.LoadFile(tempURL);

                            System.out.println("test ping: " + mainclienttest.ping());
                            //mainclienttest.send("this\nis\na \\ test!");

                            //boolean exit2 = false;

                            while (!threadexit) {
                                System.out.println("keep alive ping: " + mainclienttest.ping());

                                try {
                                    for (int i = 0; i < 50 && (!threadexit); i++) {
                                        Thread.sleep(100);
                                    }
                                } catch (InterruptedException e) {
                                    //e.printStackTrace();
                                }
                                System.out.println("Exit?: " + !threadexit);
                            }

                            System.out.println("- Exiting loop.");

                            exit = false;
                            threadexit = false;
                            //System.out.println("test ping: " + mainclienttest.ping());
                            //System.out.println("test ping: " + mainclienttest.ping());
                        }
                    }
                    else
                    {
                        if (url.indexOf('/') == -1) {
                            System.out.println("- Error establishing Connection.");
                            //mainclienttest.close();
                            error = true;
                            url = "!internals/page_not_found/roml/main.roml";
                            exit = false;
                            continue;
                        }
                    }
                }
                else
                {
                    exit = false;
                    threadexit = false;
                }
                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }

        //System.out.println("- Thread " +  threadName + " exiting.");
    }

    public void start () {
        System.out.println("- Starting " +  threadName );
        if (t == null) {
            t = new Thread (this, threadName);
            t.start ();
        }
    }
}

*/
