package com.company;

public class FileHandler {

    public static void loadWebsiteFromURL()
    {
        loadWebsiteFromURL(Main.currentURL);

    }

    public static void loadWebsiteFromURL(String url)
    {
        Main.currentURL = url;
        if (url.length() != 0)
        {
            if (url.charAt(0) == '!') {

                if (url.indexOf('/') == -1) {
                    loadWebsiteFromURL("!internals/internal_page_not_found/roml/main.roml");
                    return;
                }


                {
                    if (!url.endsWith(".roml") && !url.endsWith("/")) {
                        url += ".roml";
                    }

                    if (!url.endsWith(".roml") && url.endsWith("/")) {
                        url += "main.roml";
                    }
                }


                Main.isCurrentURLInternal = true;

                //isInternal = true;
                WebsiteInterpreter.LoadFile(getPathFromURL(url));


            }
            else
            {
                String ip = "localhost";
                String port = "1234";
                String url2 = "";


                if (url.indexOf(':') == -1 && url.indexOf('/') == -1 && url.indexOf('.') == -1) {
                    url += ":" + Main.defaultPort + "/roml/main.roml";
                }

                if (url.indexOf(':') == -1 && url.indexOf('/') == -1) {
                    loadWebsiteFromURL("!internals/server_not_found/roml/main.roml");
                    return;
                }

                if (url.indexOf(':') == -1 && url.indexOf('/') != -1) {
                    url = url.substring(0,url.indexOf('/')) + ":" + Main.defaultPort + url.substring(url.indexOf('/'));
                }

                if (url.indexOf('/') == -1) {
                    url += "/roml/main.roml";
                }

                if (!url.endsWith(".roml") && !url.endsWith("/")) {
                    url += ".roml";
                }

                if (!url.endsWith(".roml") && url.endsWith("/")) {
                    url += "main.roml";
                }


                Main.isCurrentURLInternal = false;

                WebsiteInterpreter.LoadFile(getPathFromURL(url));


            }
        }
    }

    public static String getPathFromURL(String url)
    {
        if (url.length() != 0)
        {
            //System.out.println("TEST URL AAAAAAAAAA: " + url);
            if (url.charAt(0) == '!')
            {
                StringBuilder newUrl = new StringBuilder();

                int indexOfName = url.indexOf('/');
                String mainFolder = url.substring(1, indexOfName);

                System.out.println("Main Folder: " + mainFolder);

                if (mainFolder.equals("internals"))
                    newUrl.append("data/internal/");
                else
                    return "";

                newUrl.append(url.substring(indexOfName + 1, url.length()));

                return newUrl.toString();
            }
            else
            {
                //"localhost:1234/roml/main.roml"
                String ip = url.substring(0, url.indexOf(':'));
                String port = url.substring(url.indexOf(':') + 1, url.indexOf('/'));

                String relativePath = url.substring(url.indexOf('/') + 1, url.length());


                if (downloadFileFromServer(ip, Integer.parseInt(port), relativePath))
                {
                    return "data/temp/pages/" + relativePath;
                }
                else
                {
                    return "";
                }
            }
        }
        else
        {
            return "";
        }
    }


    public static boolean downloadFileFromServer(String ip, int port, String relativeFilepath)
    {
        TCP_Client bruh = new TCP_Client(ip, port);

        if (bruh.getFilePathOfServerURL(relativeFilepath).equals(""))
        {
            bruh.close();
            return false;
        }
        else
        {
            bruh.close();
            return true;
        }


    }

    public static String sendMessageToServer(String ip, int port, String toSend, boolean awaitReply)
    {
        String reply = "";
        TCP_Client bruh = new TCP_Client(ip, port);

        bruh.send(toSend);

        if (awaitReply)
        {
            reply = bruh.receive();
        }

        bruh.close();

        return reply;
    }


}
