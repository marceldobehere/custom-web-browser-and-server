package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;

public class UI_Button
{
    public int x,y, width, height, padding;
    public boolean highlighted, border;
    public Color default_col;
    public Color highlighted_col;
    public Color border_col;
    public String name;
    public MyCanvas.icon image;
    public boolean internal;
    public Color special_col;

    public UI_Button(String name, int x, int y, int width, int height, int padding, Color default_col, Color highlighted_col, MyCanvas.icon image)
    {
        this.special_col = null;
        this.border = false;
        this.border_col = default_col;
        this.highlighted = false;
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.padding = padding;
        this.default_col = default_col;
        this.highlighted_col = highlighted_col;
        this.image = image;
        this.internal = false;
    }

    public UI_Button(String name, int x, int y, int width, int height, int padding, Color default_col, Color highlighted_col, MyCanvas.icon image, Color border_col)
    {
        this.border = true;
        this.border_col = border_col;
        this.highlighted = false;
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.padding = padding;
        this.default_col = default_col;
        this.highlighted_col = highlighted_col;
        this.image = image;
        this.internal = false;
    }

    public UI_Button(String name, int x, int y, int width, int height, int padding, Color default_col, Color highlighted_col, MyCanvas.icon image, Color border_col, boolean internal)
    {
        this.special_col = null;
        this.border = true;
        this.border_col = border_col;
        this.highlighted = false;
        this.name = name;
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.padding = padding;
        this.default_col = default_col;
        this.highlighted_col = highlighted_col;
        this.image = image;
        this.internal = internal;
    }
}


