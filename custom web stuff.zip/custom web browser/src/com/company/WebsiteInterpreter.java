package com.company;

import java.awt.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class WebsiteInterpreter
{
    public static List<WebsiteBox> allBoxes;

    public static void initialise()
    {

    }

    public static Double calculateValue(String data)
    {
        //String[] parts = data.split(java.util.regex.Matcher.quoteReplacement(" "));

        StringBuilder data2 = new StringBuilder();

        for (int i = 0; i < data.length(); i++)
        {
            if (data.charAt(i) == '$')
            {
                StringBuilder temp = new StringBuilder();
                i++;
                while (i < data.length())
                {
                    if (data.charAt(i) == '$')
                        break;

                    temp.append(data.charAt(i));
                    i++;
                }
                data2.append(getDataFromVariable(temp.toString()));
            }
            else
            {
                data2.append(data.charAt(i));
            }
        }



        return Double.parseDouble(Math(data2.toString()));
    }


    static String getDataFromVariable(String variableName)
    {
        //System.out.println("Requesting data from: " + variableName);

        if (variableName.equals("page_width"))
            return "" + ((DrawTest.canvas.windowX2 - DrawTest.canvas.windowX1) + 1);

        if (variableName.equals("page_height"))
            return "" + ((DrawTest.canvas.windowY2 - DrawTest.canvas.windowY1) + 1);

        if (variableName.equals("mouse_x")) {
            if (((DrawTest.canvas.mouseX - DrawTest.canvas.windowX1 - DrawTest.canvas.properties.scrollX) / DrawTest.canvas.properties.zoom) >= 0)
                return "" + (((DrawTest.canvas.mouseX - DrawTest.canvas.windowX1 - DrawTest.canvas.properties.scrollX) / DrawTest.canvas.properties.zoom));
            else
                return "(0 " + (((DrawTest.canvas.mouseX - DrawTest.canvas.windowX1 - DrawTest.canvas.properties.scrollX) / DrawTest.canvas.properties.zoom)) + ")";
        }


        if (variableName.equals("mouse_y"))
        {
            if (((DrawTest.canvas.mouseY - DrawTest.canvas.windowY1 - DrawTest.canvas.properties.scrollY) / DrawTest.canvas.properties.zoom) >= 0)
                return "" + (((DrawTest.canvas.mouseY - DrawTest.canvas.windowY1 - DrawTest.canvas.properties.scrollY) / DrawTest.canvas.properties.zoom));
            else
                return "(0 " + (((DrawTest.canvas.mouseY - DrawTest.canvas.windowY1 - DrawTest.canvas.properties.scrollY) / DrawTest.canvas.properties.zoom)) + ")";
        }


        return "0";
    }



    static String Math(String equation)
    {
        //System.out.println("Do Math: " + equation);
        List<Double> numbers = new ArrayList<>();
        List<Character> chars = new ArrayList<>();

        StringBuilder temp = new StringBuilder();

        for (int i = 0; i < equation.length(); i++)
        {
            char x = equation.charAt(i);
            if ("0123456789.,".contains(Character.toString(x)))
            {
                temp.append(x);
            }
            else
            {
                if (!temp.toString().equals(""))
                {
                    numbers.add(Double.parseDouble(temp.toString()));
                    temp = new StringBuilder();
                }

                if ("+-*/^".contains(Character.toString(x)))
                {
                    if (chars.size() <= numbers.size())
                    {
                        chars.add(x);
                    }
                }
                else
                {
                    if (x == '(')
                    {
                        if (!temp.toString().equals(""))
                        {
                            numbers.add(Double.parseDouble(temp.toString()));
                            temp = new StringBuilder();
                        }
                        if (chars.size() <= numbers.size() - 1)
                        {
                            chars.add('*');
                        }
                        int layer = 1;
                        i++;
                        while (layer != 0 && i < equation.length())
                        {
                            x = equation.charAt(i);
                            if (x == '(')
                            {
                                layer++;
                            }
                            if (x == ')')
                            {
                                layer--;
                            }
                            if (layer != 0)
                            {
                                temp.append(equation.charAt(i));
                            }
                            i++;
                        }
                        //Console.WriteLine("-" + temp);
                        numbers.add(Double.parseDouble(Math(temp.toString())));
                        temp = new StringBuilder();
                    }
                }

            }
        }
        if (!temp.toString().equals(""))
        {
            numbers.add(Double.parseDouble(temp.toString()));
            temp = new StringBuilder();
        }

        int index = 0;
        while ((chars.contains('*') || chars.contains('/') || chars.contains('^')) && (index < chars.size()))
        {
            if ("*/".contains(Character.toString(chars.get(index))))
            {
                if (chars.get(index) == '*')
                {
                    numbers.set(index, numbers.get(index) * numbers.get(index + 1));
                }
                if (chars.get(index) == '/')
                {
                    numbers.set(index, numbers.get(index) / numbers.get(index + 1));
                }

                chars.remove(index);
                numbers.remove(index + 1);
                index--;
            }
            index++;
        }
        index = 0;
        while ((chars.contains('+') || chars.contains('-')) && (index < chars.size()))
        {

            if ("+-".contains(Character.toString(chars.get(index))))
            {
                if  (chars.get(index) == '+')
                {
                    numbers.set(index, numbers.get(index) + numbers.get(index + 1));
                }
                if  (chars.get(index) == '-')
                {
                    numbers.set(index, numbers.get(index) - numbers.get(index + 1));
                }

                chars.remove(index);
                numbers.remove(index + 1);
                index--;
            }
            index++;
        }


        return "" + numbers.get(0);
    }

    //Character.toString

    /*
    public static String calculateString(String data)
    {
        return data;
    }
    */


    public static Color calculateColor(String data)
    {
        return Color.decode(data);
    }





    public static void LoadFile(String filename)
    {
        allBoxes = new ArrayList<>();

        try {
            System.out.println("- Reading File.");
            // open file to read
            File tempfile = new File(filename);

            if (!tempfile.exists())
            {
                Main.currentURL = "!internals/page_not_found/roml/main.roml";
                LoadFile("data/internal/internal_page_not_found/roml/main.roml");
                return;
            }



                if (Main.currentURLIndex ==  -1)
                {
                    Main.allURLs.add(Main.currentURL);
                    Main.currentURLIndex = Main.allURLs.size() - 1;
                }


            Scanner scanner = new Scanner(tempfile);



            DrawTest.canvas.properties.customURL = "";
            DrawTest.canvas.properties.pageTitle = "";



            WebsiteBox current_box = null;
            int inside_mode = 0;
            boolean inside = false;

            // read until end of file (EOF)
            while (scanner.hasNextLine()) {
                String temp = scanner.nextLine();
                String tempCompare = temp.replaceAll(java.util.regex.Matcher.quoteReplacement("\t"), "").replaceAll(java.util.regex.Matcher.quoteReplacement(" "), "");
                switch (tempCompare) {
                    case "box" -> {
                        current_box = new WebsiteBox();
                        //System.out.println("- Box");
                        inside_mode = 1;
                        continue;
                    }
                    case "page_settings" -> {
                        inside_mode = 2;
                        continue;
                    }
                    case "{" -> {
                        //System.out.println("- {");
                        inside = true;
                        continue;
                    }
                    case "}" -> {
                        //System.out.println("- }");
                        if (inside_mode == 1) {
                            allBoxes.add(current_box);
                        }
                        inside = false;
                        inside_mode = 0;
                        continue;
                    }
                }


                if (inside)
                {
                    if (inside_mode == 1)
                    {
                        StringBuilder property = new StringBuilder();
                        String value;

                        {
                            int index = 0;
                            while (index < temp.length() && (temp.charAt(index) == ' ' || temp.charAt(index) == '\t'))
                                index++;
                            while (index < temp.length() && (temp.charAt(index) != ':'))
                            {
                                property.append(temp.charAt(index));
                                index++;
                            }
                            index += 2;
                            if (index < temp.length())
                            {
                                value = temp.substring(index).replaceAll(java.util.regex.Matcher.quoteReplacement("\\n"),"\n");

                                // make value remove string quotes at the beginning and end

                                if (value.charAt(0) == '\"' && value.charAt(value.length() - 1) == '\"')
                                    value = value.substring(1, value.length() - 1);

                                //System.out.println("- Property \"" + property + "\": " + value);


                                {
                                    if (property.toString().equals("x_position"))
                                        current_box.x_position = value;
                                    else if (property.toString().equals("y_position"))
                                        current_box.y_position = value;
                                    else if (property.toString().equals("z_position"))
                                        current_box.z_position = value;
                                    else if (property.toString().equals("width"))
                                        current_box.width = value;
                                    else if (property.toString().equals("height"))
                                        current_box.height = value;

                                    else if (property.toString().equals("id"))
                                        current_box.id = value;
                                    else if (property.toString().equals("text"))
                                        current_box.text = value;
                                    else if (property.toString().equals("image"))
                                        current_box.image = value;

                                    else if (property.toString().equals("background_transparent"))
                                        current_box.background_transparent = (value.equals("true"));
                                    else if (property.toString().equals("background_color"))
                                        current_box.background_color = value;
                                    else if (property.toString().equals("border_shown"))
                                        current_box.border_shown = (value.equals("true"));
                                    else if (property.toString().equals("border_thickness"))
                                        current_box.border_thickness = value;
                                    else if (property.toString().equals("border_color"))
                                        current_box.border_color = value;
                                    else if (property.toString().equals("font_name"))
                                        current_box.font_name = value;
                                    else if (property.toString().equals("font_size"))
                                        current_box.font_size = value;
                                    else if (property.toString().equals("font_color"))
                                        current_box.font_color = value;
                                    else if (property.toString().equals("box_shown"))
                                        current_box.box_shown = (value.equals("true"));

                                }
                            }
                        }
                    }
                    else if (inside_mode == 2)
                    {
                        StringBuilder property = new StringBuilder();
                        String value;

                        {
                            int index = 0;
                            while (index < temp.length() && (temp.charAt(index) == ' ' || temp.charAt(index) == '\t'))
                                index++;
                            while (index < temp.length() && (temp.charAt(index) != ':'))
                            {
                                property.append(temp.charAt(index));
                                index++;
                            }
                            index += 2;
                            if (index < temp.length())
                            {
                                value = temp.substring(index).replaceAll(java.util.regex.Matcher.quoteReplacement("\\n"),"\n");

                                // make value remove string quotes at the beginning and end

                                if (value.charAt(0) == '\"' && value.charAt(value.length() - 1) == '\"')
                                    value = value.substring(1, value.length() - 1);

                                //System.out.println("- Property \"" + property + "\": " + value);


                                {
                                    if (property.toString().equals("url"))
                                        DrawTest.canvas.properties.customURL = value;
                                    else if (property.toString().equals("title"))
                                        DrawTest.canvas.properties.pageTitle = value;
                                }
                            }
                        }
                    }
                }
            }

            // close the scanner
            scanner.close();


        } catch (FileNotFoundException ex) {
            System.out.println("- Error reading File.");
            ex.printStackTrace();
        }







    }


}
