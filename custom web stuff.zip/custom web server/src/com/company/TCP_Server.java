package com.company;

import java.io.IOException;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;

public class TCP_Server {

    public static void listeningTest() {
        while (true)
        {
            try {
                ServerSocket serverSocket = new ServerSocket(1234);

                int socketCount = 0;

                while(true)
                {
                    Socket socket = serverSocket.accept();
                    new MainAcceptThread("Socket - " + socketCount,socket).start();
                    socketCount++;
                }

                //serverSocket.close();

            } catch (IOException e) {
                System.out.println("ERROR!");
                e.printStackTrace();
            }
        }

    }





}

class MainAcceptThread implements Runnable
{
    private Thread t;
    private String threadName;
    private Socket socket;

    private PrintWriter writer;
    private BufferedReader reader;

    private InputStream tcp_input;
    private OutputStream tcp_output;

    public boolean exit;

    MainAcceptThread( String name, Socket _socket) {
        threadName = name;
        socket = _socket;
        exit = false;
        //System.out.println("- Creating " +  threadName );
    }

    public void run() {
        System.out.println("- Running " +  threadName );
        try {

            tcp_output = socket.getOutputStream();
            writer = new PrintWriter(tcp_output, true);
            tcp_input = socket.getInputStream();
            reader = new BufferedReader(new InputStreamReader(tcp_input));

            socket.setKeepAlive(true);
            socket.setSoTimeout(1000000);

            while (socket.isConnected() && !exit)
            {
                String received = receive();
                System.out.println("Received: " + received);

                if (received.equals("PING"))
                {
                    System.out.println("- Got pinged.");
                    send("PONG");
                    continue;
                }

                if (received.startsWith("GIB_FILE "))
                {
                    String filepath = received.substring(received.indexOf(' ') + 1);
                    System.out.println("- Got File-Request (" + filepath + ").");

                    sendFile(Main.serverFolderName + "/" + filepath);
                    continue;
                }



                System.out.println("Enter Reply: ");
                int counter = 0;
                Main.userInput = "";
                while (counter < 20 && Main.userInput.equals(""))
                {
                    Thread.sleep(100);
                    counter++;
                }
                if (counter < 20)
                {
                    if (Main.userInput.equals("/exit"))
                    {
                        System.out.println("- Closing Socket " + threadName + ".");
                        exit = true;
                        socket.close();
                    }

                    else
                    {
                        String toSend = Main.userInput;
                        send(toSend);
                    }
                }
                else
                    System.out.println("- (No Input given)");



                //consoleInput.hasNext();

                if (!socket.isConnected())
                {
                    System.out.println("- Socket has been closed.");
                    exit = true;
                }
                else if (socket == null)
                {
                    System.out.println("- Socket doesn't exist anymore.");
                    exit = true;
                }
                else if (socket.isClosed() || !socket.isBound())
                {
                    System.out.println("- Socket doesn't exist anymore.");
                    exit = true;
                }
                else if (false)
                {

                }
            }
            /*
            InputStream input = socket.getInputStream();

            BufferedReader reader = new BufferedReader(new InputStreamReader(input));
            String line = reader.readLine();    // reads a line of text

            System.out.println("Client: " + line);

            OutputStream output = socket.getOutputStream();

            Scanner consoleInput = new Scanner(System.in);
            System.out.println("Enter Reply: ");
            String toSend = consoleInput.next();

            PrintWriter writer = new PrintWriter(output, true);
            writer.println(toSend);
            */

            System.out.println("- Socket " + threadName + " closing.");




        } catch (IOException e) {
            System.out.println("- Thread " +  threadName + " interrupted.");
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println("- Thread " +  threadName + " exiting.");
    }

    public void start () {
        System.out.println("- Starting " +  threadName );
        if (t == null) {
            t = new Thread (this, threadName);
            t.start ();
        }
    }


    public void close()
    {
        System.out.println("- Closing Socket.");
        try {
            socket.close();
        } catch (IOException e) {
            System.out.println("- Error closing Socket.");
            //e.printStackTrace();
        }
    }


    public void send(String data)
    {
        try
        {
            String tempData = data;
            //System.out.println("temp send 1: " + tempData);
            String processedData = tempData.replaceAll(java.util.regex.Matcher.quoteReplacement("!"),"!!").replaceAll(java.util.regex.Matcher.quoteReplacement("\n"),"!n");
            //System.out.println("temp send 2: " + processedData);
            writer.println(processedData);
        }
        catch (NullPointerException e)
        {
            System.out.println("- Error sending Data.");
            exit = true;
            System.out.println("- Closing Socket.");
        }
    }


    public String receive()
    {
        try {
            String tempData = reader.readLine();
            //System.out.println("temp rec 1: " + tempData);
            String processedData = "";

            if (tempData != null)
            {
                try
                {
                    processedData = tempData.replaceAll(java.util.regex.Matcher.quoteReplacement("!n"),"\n").replaceAll(java.util.regex.Matcher.quoteReplacement("!!"),"!");
                }
                catch (NullPointerException e)
                {
                    System.out.println("- Error receiving Data (2).");
                    exit = true;
                    System.out.println("- Closing Socket.");
                }
            }
            else
            {
                System.out.println("- Error receiving Data (3).");
                exit = true;
                System.out.println("- Closing Socket.");
            }
            return processedData;
        } catch (IOException e) {
            System.out.println("- Error receiving Data.");
            //e.printStackTrace();
            exit = true;
            System.out.println("- Closing Socket.");
        }
        return "";
    }


    public void sendFile(String filepath)
    {
        try {
            File tempFile = new File(filepath);

            if (tempFile.exists())
            {
                Path path = Paths.get(filepath);
                int bytes = (int)Files.size(path);

                send("size: " + bytes);
                if (receive().equals("OK"))
                {
                    byte[] b = new byte[bytes];

                    BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filepath));
                    bis.read(b);

                    tcp_output.write(b,0,bytes);

                    System.out.println("File upload completed");
                }
                else {
                    System.out.println("- Error sending File.");
                    socket.close();
                    exit = true;
                    System.out.println("- Closing Socket.");
                }
            }
            else
            {
                send("FILE_NOT_FOUND");
            }

        } catch (IOException e) {
            System.out.println("- Error sending File.");
            //e.printStackTrace();
            exit = true;
            System.out.println("- Closing Socket.");
        }
    }

    public boolean receiveFile(String filepath)
    {
        try {
            File file = new File(filepath);
            Files.createDirectories(Paths.get(file.getParent()));

            String sizeString = receive();
            if (sizeString.startsWith("size: "))
            {
                int size = Integer.parseInt(sizeString.substring(sizeString.indexOf(' ') + 1));
                byte[] buffer = new byte[size];

                send("OK");

                tcp_input.read(buffer);

                OutputStream output = new FileOutputStream(filepath);
                output.write(buffer, 0, size);
                output.close();


                System.out.println("- Done downloading");
                return true;
            }
            else if(sizeString.equals("FILE_NOT_FOUND"))
            {
                System.out.println("- Error File not found");
                return false;
            }

        } catch (IOException e) {
            System.out.println("- Error receiving File.");
            //e.printStackTrace();
            exit = true;
            System.out.println("- Closing Socket.");
            return false;
        }
        return false;
    }







}