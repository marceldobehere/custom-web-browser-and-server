package com.company;

import java.util.Scanner;

public class Main {

    public static String userInput;
    public static String serverFolderName;

    public static void main(String[] args) {
        System.out.println("hello world");

        new MainInputThread().start();

        serverFolderName = "testing";

        System.out.println("Starting Webserver test");
        TCP_Server.listeningTest();

    }
}

class MainInputThread extends Thread {
    public void run() {
        Scanner consoleInput = new Scanner(System.in);
        while(true)
        {
            Main.userInput = consoleInput.next();
            //System.out.println("input: " + Main.userInput);
        }
    }
}

