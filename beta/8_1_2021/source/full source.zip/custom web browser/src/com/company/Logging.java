package com.company;

import java.util.Dictionary;
import java.util.Hashtable;

public class Logging {
    public static boolean logToConsole;

    public enum logtype{
        normal,
        notification,
        warning,
        error,
        script_output,
        script_notification,
        script_warning,
        script_error,
        in_script_normal,
        in_script_notification,
        in_script_warning,
        in_script_error
    }

    public static Dictionary<logtype, Boolean> logtoConsoleDict;


    //Logging.log("", Logging.logtype.normal);

    public static void init()
    {
        logToConsole = true;
        logtoConsoleDict = new Hashtable<>();
        logtoConsoleDict.put(logtype.normal, true);
        logtoConsoleDict.put(logtype.notification, true);
        logtoConsoleDict.put(logtype.warning, true);
        logtoConsoleDict.put(logtype.error, true);
        logtoConsoleDict.put(logtype.script_output, true);
        logtoConsoleDict.put(logtype.script_notification, true);
        logtoConsoleDict.put(logtype.script_warning, true);
        logtoConsoleDict.put(logtype.script_error, true);
        logtoConsoleDict.put(logtype.in_script_normal, true);
        logtoConsoleDict.put(logtype.in_script_notification, true);
        logtoConsoleDict.put(logtype.in_script_warning, true);
        logtoConsoleDict.put(logtype.in_script_error, true);
    }

    public static void log(String message, logtype type)
    {
        if (logToConsole)
        {
            if (logtoConsoleDict.get(type))
            {
                if (type.equals(logtype.normal))
                    System.out.println("- " + message + Console_Color.RESET);
                else if (type.equals(logtype.notification))
                    System.out.println(Console_Color.YELLOW_BRIGHT + "- Info: " + message + Console_Color.RESET);
                else if (type.equals(logtype.warning))
                    System.out.println(Console_Color.RED_BRIGHT + "- Warning: " + message + Console_Color.RESET);
                else if (type.equals(logtype.error))
                    System.out.println(Console_Color.RED_BOLD + "- MAIN ERROR: " + message + Console_Color.RESET);


                else if (type.equals(logtype.script_output))
                    System.out.println("- Script: " + message + Console_Color.RESET);
                else if (type.equals(logtype.script_notification))
                    System.out.println(Console_Color.YELLOW_BRIGHT + "- Script Info: " + message + Console_Color.RESET);
                else if (type.equals(logtype.script_warning))
                    System.out.println(Console_Color.RED_BRIGHT + "- Script Warning: " + message + Console_Color.RESET);
                else if (type.equals(logtype.script_error))
                    System.out.println(Console_Color.RED_BOLD + "- SCRIPT ERROR: " + message + Console_Color.RESET);

                else if (type.equals(logtype.in_script_normal))
                    System.out.println("- In Script: " + message + Console_Color.RESET);
                else if (type.equals(logtype.in_script_notification))
                    System.out.println(Console_Color.YELLOW_BRIGHT + "- In Script Info: " + message + Console_Color.RESET);
                else if (type.equals(logtype.in_script_warning))
                    System.out.println(Console_Color.RED_BRIGHT + "- In Script Warning: " + message + Console_Color.RESET);
                else if (type.equals(logtype.in_script_error))
                    System.out.println(Console_Color.RED_BOLD + "- IN SCRIPT ERROR: " + message + Console_Color.RESET);
            }
        }

    }

}
