package com.company;

import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;

import javax.swing.JComponent;
import javax.swing.JFrame;

public class DrawTest{

    public static MyCanvas canvas;
    public static JFrame jf;
    public static boolean allow_drawing;


    public static void main() {
        jf = new JFrame("Marceldobehere's CustomWeb-Browser");
        Container cp = jf.getContentPane();
        allow_drawing = false;
        JTextField textField = new JTextField();

        textField.addKeyListener(new Keychecker());
        textField.setFocusTraversalKeysEnabled(false);

        cp.add(textField);

        canvas = new MyCanvas();
        cp.add(canvas);
        jf.setSize(1280, 720);
        jf.setVisible(true);
        jf.setResizable(true);
        jf.setMinimumSize(new Dimension(1024,576));
        canvas.toWrite = "";

        // Set to exit on close
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }

}

class Keychecker extends KeyAdapter {

    @Override
    public void keyPressed(KeyEvent event) {

        char ch = event.getKeyChar();
        if (event.getKeyCode() == 16)
        {
            return;
        }
        if (event.getKeyCode() == 17)
        {
            //return;
        }
        if (event.getKeyCode() == 27)
        {
            DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;
            Logging.log("Escape Pressed", Logging.logtype.notification);
            DrawTest.canvas.toWrite = "";
            DrawTest.canvas.update();
            return;
        }

        if (DrawTest.canvas.selectedThing == MyCanvas.selectedthings.none)
        {
            if (event.isControlDown())
            {
                if (event.getKeyCode() == 521)
                {
                    if (DrawTest.canvas.properties.zoom < 10)
                        DrawTest.canvas.properties.zoom += 0.2;
                    return;
                }
                else if (event.getKeyCode() == 45)
                {
                    if (DrawTest.canvas.properties.zoom > 0.4)
                        DrawTest.canvas.properties.zoom -= 0.2;
                    //System.out.println("ZOOM OUT " + DrawTest.canvas.properties.zoom);
                    return;
                }
                else if (event.getKeyCode() == 37)
                {
                    //System.out.println("GO LEFT");
                    DrawTest.canvas.properties.scrollX += 5;
                    return;
                }
                else if (event.getKeyCode() == 38)
                {
                    //System.out.println("GO UP");
                    DrawTest.canvas.properties.scrollY += 5;
                    return;
                }
                else if (event.getKeyCode() == 39)
                {
                    //System.out.println("GO RIGHT");
                    DrawTest.canvas.properties.scrollX -= 5;
                    return;
                }
                else if (event.getKeyCode() == 40)
                {
                    //System.out.println("GO DOWN");
                    DrawTest.canvas.properties.scrollY -= 5;
                    return;
                }
            }
        }
        else if (DrawTest.canvas.selectedThing == MyCanvas.selectedthings.search_bar)
        {
            if (event.getKeyCode() == 8) // Backspace
            {
                if (Main.currentURL.length() != 0)
                {
                    Main.currentURL = Main.currentURL.substring(0,Main.currentURL.length() - 1);
                    DrawTest.canvas.update();
                }
                return;
            }
            else if (event.getKeyCode() == KeyEvent.VK_TAB) // Tab
            {
                Main.currentURL = "";
                DrawTest.canvas.update();
                return;
            }
            else if (event.getKeyCode() == 10) // Enter
            {
                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;
                Main.currentURLIndex = -1;

                FileHandler.loadWebsiteFromURL();

                DrawTest.canvas.update();
                return;
            }


            Main.currentURL += ch;

        }

        DrawTest.canvas.update();
    }

}
