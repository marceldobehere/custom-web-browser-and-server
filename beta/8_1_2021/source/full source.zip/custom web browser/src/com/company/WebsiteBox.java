package com.company;

import java.awt.*;
import java.awt.image.BufferedImage;

public class WebsiteBox
{
    public String x_position;
    public String y_position;
    public String z_position;
    public String width;
    public String height;

    public String id;
    public String text;
    public String image;

    public String oldImage;
    public Image bufferedImage;

    public boolean background_transparent;
    public String background_color;
    public boolean border_shown;
    public String border_thickness;
    public String border_color;
    public String font_name;
    public String font_size;
    public String font_color;
    public boolean box_shown;

    public String script_box_clicked;
    public boolean highlighted;


    public WebsiteBox()
    {
        x_position = "0";
        y_position = "0";
        z_position = "0";
        height = "1";
        width = "1";

        id = "";
        text = "";
        image = "";

        background_transparent = true;
        background_color = "#000000";
        border_shown = false;
        border_thickness = "1";
        border_color = "#EEEEFF";
        font_name = "Bahnschrift";
        font_size = "20";
        font_color = "#E0E0FF";
        box_shown = true;

        script_box_clicked = "";
        highlighted = false;



        /*

                        tempButton.highlighted = (
                        (
                                (mouseX >= tempButton.x + tempButton.padding) && (mouseX < tempButton.x + tempButton.width - tempButton.padding)
                        ) && (
                                (mouseY >= tempButton.y + tempButton.padding) && (mouseY < tempButton.y + tempButton.height - tempButton.padding)
                        )
                );
         */


        oldImage = "";
        bufferedImage = DrawTest.canvas.iconmap.get(MyCanvas.icon.temp_image);
    }

    public static void setProperty(String property, String value, WebsiteBox current_box)
    {
        {
            if (property.toString().equals("x_position"))
                current_box.x_position = value;
            else if (property.toString().equals("y_position"))
                current_box.y_position = value;
            else if (property.toString().equals("z_position"))
                current_box.z_position = value;
            else if (property.toString().equals("width"))
                current_box.width = value;
            else if (property.toString().equals("height"))
                current_box.height = value;

            else if (property.toString().equals("id"))
                current_box.id = value;
            else if (property.toString().equals("text"))
                current_box.text = value;
            else if (property.toString().equals("image"))
                current_box.image = value;

            else if (property.toString().equals("background_transparent"))
                current_box.background_transparent = (value.equals("true"));
            else if (property.toString().equals("background_color"))
                current_box.background_color = value;
            else if (property.toString().equals("border_shown"))
                current_box.border_shown = (value.equals("true"));
            else if (property.toString().equals("border_thickness"))
                current_box.border_thickness = value;
            else if (property.toString().equals("border_color"))
                current_box.border_color = value;
            else if (property.toString().equals("font_name"))
                current_box.font_name = value;
            else if (property.toString().equals("font_size"))
                current_box.font_size = value;
            else if (property.toString().equals("font_color"))
                current_box.font_color = value;
            else if (property.toString().equals("box_shown"))
                current_box.box_shown = (value.equals("true"));
            else if (property.toString().equals("script_box_clicked"))
                current_box.script_box_clicked = value;
            else if (property.toString().equals("highlighted"))
                current_box.highlighted = (value.equals("true"));
            else
                Logging.log("Property \"" + property + "\" not found!", Logging.logtype.error);

        }
    }
    public static String getProperty(String property, WebsiteBox current_box)
    {
        {
            if (property.toString().equals("x_position"))
                return current_box.x_position;
            else if (property.toString().equals("y_position"))
                return current_box.y_position;
            else if (property.toString().equals("z_position"))
                return current_box.z_position;
            else if (property.toString().equals("width"))
                return current_box.width;
            else if (property.toString().equals("height"))
                return current_box.height;

            else if (property.toString().equals("id"))
                return current_box.id;
            else if (property.toString().equals("text"))
                return current_box.text;
            else if (property.toString().equals("image"))
                return current_box.image;

            else if (property.toString().equals("background_transparent"))
                return (current_box.background_transparent ? "true":"false");
            else if (property.toString().equals("background_color"))
                return current_box.background_color;
            else if (property.toString().equals("border_shown"))
                return (current_box.border_shown ? "true":"false");
            else if (property.toString().equals("border_thickness"))
                return current_box.border_thickness;
            else if (property.toString().equals("border_color"))
                return current_box.border_color;
            else if (property.toString().equals("font_name"))
                return current_box.font_name;
            else if (property.toString().equals("font_size"))
                return current_box.font_size;
            else if (property.toString().equals("font_color"))
                return current_box.font_color;
            else if (property.toString().equals("box_shown"))
                return (current_box.box_shown ? "true":"false");
            else if (property.toString().equals("script_box_clicked"))
                return current_box.script_box_clicked;
            else if (property.toString().equals("highlighted"))
                return (current_box.highlighted ? "true":"false");
            else
                Logging.log("Property \"" + property + "\" not found!", Logging.logtype.error);

            return "";
        }
    }


}
