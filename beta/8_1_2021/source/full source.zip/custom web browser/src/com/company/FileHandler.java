package com.company;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;

public class FileHandler {

    public static void loadWebsiteFromURL()
    {
        loadWebsiteFromURL(Main.currentURL);

    }

    public static void loadWebsiteFromURL(String url)
    {
        Main.currentURL = url;
        if (url.length() != 0)
        {
            if (url.charAt(0) == '!') {

                if (url.indexOf('/') == -1) {
                    loadWebsiteFromURL("!internals/internal_page_not_found/roml/main.roml");
                    return;
                }


                {
                    if (!url.endsWith(".roml") && !url.endsWith("/")) {
                        url += ".roml";
                    }

                    if (!url.endsWith(".roml") && url.endsWith("/")) {
                        url += "main.roml";
                    }
                }


                Main.isCurrentURLInternal = true;
                {
                    File temp = new File("data/temp/page/");
                    deleteFolder(temp);
                    temp.mkdir();
                }
                //isInternal = true;
                WebsiteInterpreter.LoadFile(getPathFromURL(url));


            }
            else if (url.equals("home"))
            {
                loadWebsiteFromURL("!internals/home_page/roml/main.roml");
                return;
            }
            else if (url.equals("help"))
            {
                loadWebsiteFromURL("!internals/help/roml/main.roml");
                return;
            }
            else if (url.equals("not_found"))
            {
                loadWebsiteFromURL("!internals/page_not_found/roml/main.roml");
                return;
            }
            else if (url.equals("settings"))
            {
                loadWebsiteFromURL("!internals/settings/roml/main.roml");
                return;
            }
            else
            {
                String ip = "localhost";
                String port = "1234";
                String url2 = "";


                if (url.indexOf(':') == -1 && url.indexOf('/') == -1 && url.indexOf('.') == -1) {
                    url += ":" + Main.defaultPort + "/roml/main.roml";
                }

                if (url.indexOf(':') == -1 && url.indexOf('/') == -1) {
                    loadWebsiteFromURL("!internals/server_not_found/roml/main.roml");
                    return;
                }

                if (url.indexOf(':') == -1 && url.indexOf('/') != -1) {
                    url = url.substring(0,url.indexOf('/')) + ":" + Main.defaultPort + url.substring(url.indexOf('/'));
                }

                if (url.indexOf('/') == -1) {
                    url += "/roml/main.roml";
                }

                if (!url.endsWith(".roml") && !url.endsWith("/")) {
                    url += ".roml";
                }

                if (!url.endsWith(".roml") && url.endsWith("/")) {
                    url += "main.roml";
                }


                Main.isCurrentURLInternal = false;
                {
                    File temp = new File("data/temp/page/");
                    deleteFolder(temp);
                    temp.mkdir();
                }

                WebsiteInterpreter.LoadFile(getPathFromURL(url));


            }
        }
    }

    public static void deleteFolder(File folder) {
        File[] files = folder.listFiles();
        if(files!=null) { //some JVMs return null for empty dirs
            for(File f: files) {
                if(f.isDirectory()) {
                    deleteFolder(f);
                } else {
                    f.delete();
                }
            }
        }
        folder.delete();
    }

    public static String getPathFromURL(String url)
    {
        if (url.length() != 0)
        {
            //System.out.println("TEST URL AAAAAAAAAA: " + url);
            if (url.charAt(0) == '!')
            {
                StringBuilder newUrl = new StringBuilder();

                int indexOfName = url.indexOf('/');
                String mainFolder = url.substring(1, indexOfName);

                Logging.log("Main Internal Folder: " + mainFolder, Logging.logtype.notification);

                if (mainFolder.equals("internals"))
                    newUrl.append("data/internal/");
                else if (mainFolder.equals("site"))
                    newUrl.append("data/temp/");
                else
                    return "";

                newUrl.append(url.substring(indexOfName + 1));

                int indexOfName2 = indexOfName + 1 + url.substring(indexOfName + 1).indexOf('/');

                String tempPath = "data/temp/page/" + url.substring(indexOfName2 + 1);

                //System.out.println("PATH AAAAAAAAAAAAA: " + tempPath);

                {
                    File copied = new File(tempPath);
                    File newUrlFile = new File(newUrl.toString());
                    if (newUrlFile.exists())
                    {
                        if (!copied.exists()) {
                            try {
                                Files.createDirectories(Paths.get(copied.getParent()));
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            try (
                                    InputStream in = new BufferedInputStream(
                                            new FileInputStream(newUrlFile));
                                    OutputStream out = new BufferedOutputStream(
                                            new FileOutputStream(copied))) {

                                byte[] buffer = new byte[1024];
                                int lengthRead;
                                while ((lengthRead = in.read(buffer)) > 0) {
                                    out.write(buffer, 0, lengthRead);
                                    out.flush();
                                }
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                        }
                    }
                    else
                    {
                        Logging.log("File not found!", Logging.logtype.error);
                        return getPathFromURL("!internals/internal_page_not_found/roml/main.roml");
                    }
                }


                return tempPath;
            }
            else
            {
                //System.out.println("test: " + url);
                if (url.indexOf(':') == -1 || url.indexOf('/') == -1)
                    return "";


                //"localhost:1234/roml/main.roml"
                String ip = url.substring(0, url.indexOf(':'));
                String port = url.substring(url.indexOf(':') + 1, url.indexOf('/'));

                String relativePath = url.substring(url.indexOf('/') + 1, url.length());


                if (downloadFileFromServer(ip, Integer.parseInt(port), relativePath))
                {
                    return "data/temp/page/" + relativePath;
                }
                else
                {
                    return getPathFromURL("!internals/server_not_found/roml/main.roml");
                }
            }
        }
        else
        {
            return "";
        }
    }


    public static boolean downloadFileFromServer(String ip, int port, String relativeFilepath)
    {
        TCP_Client bruh = new TCP_Client(ip, port);

        Logging.log("downloading file: " + ip + ", " + port + ", " + relativeFilepath, Logging.logtype.notification);

        if (bruh.getFilePathOfServerURL(relativeFilepath).equals(""))
        {
            bruh.close();
            return false;
        }
        else
        {
            bruh.close();
            return true;
        }


    }

    public static String sendMessageToServer(String ip, int port, String toSend, boolean awaitReply)
    {
        String reply = "";
        TCP_Client bruh = new TCP_Client(ip, port);

        bruh.send(toSend);

        if (awaitReply)
        {
            reply = bruh.receive();
        }

        bruh.close();

        return reply;
    }


}
