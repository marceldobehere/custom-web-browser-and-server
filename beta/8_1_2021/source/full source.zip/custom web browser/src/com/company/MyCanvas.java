package com.company;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.AffineTransform;
import java.awt.image.AffineTransformOp;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.List;

import static java.lang.System.exit;
import static java.lang.System.in;


public class MyCanvas extends JComponent {

    public String toWrite;
    public int sizeX, sizeY, mouseX, mouseY, windowX1, windowX2, windowY1, windowY2;

    private List<UI_Button> buttons;

    private Map<cols, Color> colormap;
    public Map<icon, BufferedImage> iconmap;

    public String hostname_adress;

    public selectedthings selectedThing;

    public Properties properties;

    public class Properties
    {
        public Properties()
        {
            customURL = "";
            pageTitle = "";
            scrollX = 0;
            scrollY = 0;
            zoom = 1;
        }


        public int scrollX, scrollY;
        public double zoom;

        public String customURL;
        public String pageTitle;
    }




    public enum selectedthings{
        none,
        search_bar,
        search_button,
        back,
        front,
        settings,
        reload,
        home
    }

    public enum cols
    {
        background_main,
        background_tabs,
        background_window,
        seperator_line,
        default_text,
        default_button,
        default_button_highlighted,
        default_button_highlighted_dark,
        border
    }

    public enum icon
    {
        none,
        reload,
        back,
        front,
        search,
        settings,
        temp_image,
        home
    }


    public MyCanvas()
    {
        selectedThing = selectedthings.none;
        //add(new MouseDetectionThingy());
        DrawTest.jf.addMouseListener(new MouseDetectionThingy());

        hostname_adress = Main.currentURL;

        sizeX = getWidth();
        sizeY = getHeight();

        properties = new Properties();

       colormap = new HashMap<cols, Color>();

       float[] temp;
        temp = Color.RGBtoHSB(10,10,20, null);
        colormap.put(cols.background_main, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(5,5,10, null);
        colormap.put(cols.background_window, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(20,20,40, null);
        colormap.put(cols.background_tabs, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(120,120,150, null);
        colormap.put(cols.seperator_line, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(140,140,170, null);
        colormap.put(cols.border, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(200,200,220, null);
        colormap.put(cols.default_text, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(40,40,60, null);
        colormap.put(cols.default_button, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(80,80,100, null);
        colormap.put(cols.default_button_highlighted, Color.getHSBColor(temp[0], temp[1], temp[2]));

        temp = Color.RGBtoHSB(60,60,80, null);
        colormap.put(cols.default_button_highlighted_dark, Color.getHSBColor(temp[0], temp[1], temp[2]));


        iconmap = new HashMap<icon, BufferedImage>();

        try {

            iconmap.put(icon.reload, ImageIO.read(new File("data/icons/reload.png")));
            iconmap.put(icon.back, ImageIO.read(new File("data/icons/back.png")));
            iconmap.put(icon.front, ImageIO.read(new File("data/icons/front.png")));
            iconmap.put(icon.search, ImageIO.read(new File("data/icons/search.png")));
            iconmap.put(icon.settings, ImageIO.read(new File("data/icons/settings.png")));
            iconmap.put(icon.temp_image, ImageIO.read(new File("data/icons/temp_image.png")));
            iconmap.put(icon.home, ImageIO.read(new File("data/icons/home.png")));

        } catch (IOException e) {
            Logging.log("Image File not found!", Logging.logtype.error);
            //System.out.println(e);
            exit(-1);
        }


        buttons = new ArrayList<>();


        buttons.add(new UI_Button("Reload",1, 31, 30,30, 3, colormap.get(cols.default_button),colormap.get(cols.default_button_highlighted), icon.reload, colormap.get(cols.border), true));

        buttons.add(new UI_Button("Back",31, 31, 30,30, 3, colormap.get(cols.default_button),colormap.get(cols.default_button_highlighted), icon.back, colormap.get(cols.border), true));
        buttons.add(new UI_Button("Front",61, 31, 30,30, 3, colormap.get(cols.default_button),colormap.get(cols.default_button_highlighted), icon.front, colormap.get(cols.border), true));
        buttons.add(new UI_Button("Search Button",121, 31, 30,30, 3, colormap.get(cols.default_button),colormap.get(cols.default_button_highlighted), icon.search, colormap.get(cols.border), true));

        buttons.add(new UI_Button("Home Button",91, 31, 30,30, 3, colormap.get(cols.default_button),colormap.get(cols.default_button_highlighted), icon.home, colormap.get(cols.border), true));

        buttons.add(new UI_Button("Search Box",151, 31, 300,30, 3, colormap.get(cols.default_button),colormap.get(cols.default_button_highlighted_dark), icon.none, colormap.get(cols.border), true));
        buttons.add(new UI_Button("Settings",sizeX - 32, 31, 30,30, 3, colormap.get(cols.default_button),colormap.get(cols.default_button_highlighted), icon.settings, colormap.get(cols.border), true));
    }


    public UI_Button getButton(boolean internal, String name)
    {
        for (int i = 0; i < buttons.size(); i++)
        {
            UI_Button temp = buttons.get(i);
            if (temp.internal == internal && temp.name.equals(name))
            {
                return temp;
            }
        }



        return null;
    }



    public void MouseClickDetection()
    {
        selectedthings _old = selectedThing;
        selectedthings _new = selectedthings.none;


        {
            if (getButton(true, "Search Box").highlighted)
                _new = selectedthings.search_bar;
            if (getButton(true, "Search Button").highlighted)
                _new = selectedthings.search_button;

            if (getButton(true, "Reload").highlighted)
                _new = selectedthings.reload;
            if (getButton(true, "Back").highlighted)
                _new = selectedthings.back;
            if (getButton(true, "Front").highlighted)
                _new = selectedthings.front;
            if (getButton(true, "Settings").highlighted){

                Main.currentURL = "settings";
                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;
                Main.currentURLIndex = -1;

                FileHandler.loadWebsiteFromURL();

                _new = selectedthings.none;
            }
            if (getButton(true, "Home Button").highlighted) {

                Main.currentURL = "home";
                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;
                Main.currentURLIndex = -1;

                FileHandler.loadWebsiteFromURL();

                _new = selectedthings.none;
            }




            selectedThing = _new;
        }


        {
            //System.out.println("AAAAAA");
            for (int i = 0; i < WebsiteInterpreter.allBoxes.size(); i++)
            {
                if (WebsiteInterpreter.allBoxes.get(i).highlighted)
                {
                    WebsiteBox tempBox = WebsiteInterpreter.allBoxes.get(i);
                    String scriptUrl = tempBox.script_box_clicked;
                    for (int i2 = 0; i2 < ScriptInterpreterManager.scriptInstanceNames.size(); i2++)
                    {

                        if (ScriptInterpreterManager.scriptInstanceNames.get(i2).equals(scriptUrl))
                        {
                            ScriptInterpreterManager.scriptInstances.get(i2).CallFunctionFromExternal("box_clicked", new Variable[]{new Variable(tempBox.id)});
                        }
                    }

                }
            }
        }



        if(_old != _new)
        {
            if (_new == selectedthings.reload)
            {
                if (Main.currentURLIndex > -1 && Main.currentURLIndex < Main.allURLs.size())
                    Main.currentURL = Main.allURLs.get(Main.currentURLIndex);

                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;

                FileHandler.loadWebsiteFromURL();
                DrawTest.canvas.update();
            }
            else if (_new == selectedthings.search_button)
            {
                Main.currentURLIndex = -1;
                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;

                FileHandler.loadWebsiteFromURL();

                DrawTest.canvas.update();
            }
            else if (_new == selectedthings.back)
            {
                //System.out.println("INDEX: " + Main.currentURLIndex + ". SIZE: " + Main.allURLs.size());
                if (Main.currentURLIndex > 0)
                    Main.currentURLIndex--;

                if (Main.currentURLIndex > -1 && Main.currentURLIndex < Main.allURLs.size())
                    Main.currentURL = Main.allURLs.get(Main.currentURLIndex);


                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;


                FileHandler.loadWebsiteFromURL();

                DrawTest.canvas.update();
            }
            else if (_new == selectedthings.front)
            {
                if ((Main.currentURLIndex + 1) < Main.allURLs.size())
                    Main.currentURLIndex++;

                if (Main.currentURLIndex > -1 && Main.currentURLIndex < Main.allURLs.size())
                    Main.currentURL = Main.allURLs.get(Main.currentURLIndex);


                DrawTest.canvas.selectedThing = MyCanvas.selectedthings.none;


                FileHandler.loadWebsiteFromURL();

                DrawTest.canvas.update();
            }
            else if (_old == selectedthings.none)
            {
                if (_new == selectedthings.search_bar)
                {
                    Logging.log("Clicked on Searchbox.", Logging.logtype.notification);
                }



            }
            else if (_old == selectedthings.search_bar)
            {
                if (_new == selectedthings.none)
                {
                    Logging.log("UNClicked on Searchbox.", Logging.logtype.notification);
                }




            }

        }
        else
        {

        }
    }



    public static BufferedImage toBufferedImage(Image img)
    {
        if (img instanceof BufferedImage)
        {
            return (BufferedImage) img;
        }

        // Create a buffered image with transparency
        BufferedImage bimage = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);

        // Draw the image on to the buffered image
        Graphics2D bGr = bimage.createGraphics();
        bGr.drawImage(img, 0, 0, null);
        bGr.dispose();

        // Return the buffered image
        return bimage;
    }



    @Override
    public void paintComponent(Graphics g) {
        if (g instanceof Graphics2D && DrawTest.allow_drawing) {
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);


            {
                sizeX = getWidth();
                sizeY = getHeight();

                PointerInfo a = MouseInfo.getPointerInfo();
                Point b = a.getLocation() ;
                mouseX = (int) b.getX() - getLocationOnScreen().x;
                mouseY = (int) b.getY() - getLocationOnScreen().y;

                windowX1 = 1;
                windowY1 = 62;

                windowX2 = sizeX - 1;
                windowY2 = sizeY - 1;

                hostname_adress = Main.currentURL;
            }


            g2.setColor(colormap.get(cols.background_window));
            g2.fillRect(windowX1,windowY1,windowX2, windowY2);


            // drawing of text blocks
            {
                int count = WebsiteInterpreter.allBoxes.size();
                boolean[] drawn = new boolean[count];
                int lasthighlightedindex = -1;
                //System.out.println("size: " + count);
                while(count_arr(drawn, false) > 0)
                {
                    int i = 0;
                    double ival = Double.MAX_VALUE;
                    for (int temp = 0; temp < drawn.length; temp++)
                    {
                        if (!drawn[temp])
                        {
                            if (WebsiteInterpreter.calculateValue(WebsiteInterpreter.allBoxes.get(temp).z_position) < ival)
                            {
                                i = temp;
                                ival = WebsiteInterpreter.calculateValue(WebsiteInterpreter.allBoxes.get(i).z_position);
                            }
                        }
                    }

                    drawn[i] = true;

                    WebsiteBox temp = WebsiteInterpreter.allBoxes.get(i);
                    if (temp.box_shown) {
                        if (!temp.background_transparent) {
                            //System.out.println("aaa");
                            g2.setColor(WebsiteInterpreter.calculateColor(temp.background_color));
                            g2.fillRect(windowX1 + (int) (properties.scrollX + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.x_position)))), windowY1 + (int) (properties.scrollY + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.y_position)))), (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.width)), (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.height)));
                        }

                        if (temp.border_shown) {
                            //System.out.println("aaa");
                            g2.setColor(WebsiteInterpreter.calculateColor(temp.border_color));
                            double thickness = WebsiteInterpreter.calculateValue(temp.border_thickness);
                            if (thickness < 0)
                                thickness = 0;
                            Stroke oldStroke = g2.getStroke();
                            g2.setStroke(new BasicStroke((float) thickness));
                            g2.drawRect(windowX1 + (int) (properties.scrollX + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.x_position)))), windowY1 + (int) (properties.scrollY + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.y_position)))), (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.width)), (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.height)));
                            g2.setStroke(oldStroke);
                        }

                        {
                            int x1 = windowX1 + (int) (properties.scrollX + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.x_position))));
                            int y1 = windowY1 + (int) (properties.scrollY + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.y_position))));
                            int x2 = x1 + (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.width));
                            int y2 = y1 + (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.height));

                            if (
                                    (
                                        (mouseX >= x1) && (mouseX < x2)
                                    ) && (
                                        (mouseY >= y1) && (mouseY < y2)
                                    )
                            )
                                lasthighlightedindex = i;

                            temp.highlighted = false;

                        }


                        if (!temp.text.equals("")) {
                            Font tempFont = new Font(temp.font_name, Font.PLAIN, (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.font_size)));
                            FontMetrics metrics = g.getFontMetrics(tempFont);
                            g2.setFont(tempFont);

                            g2.setColor(WebsiteInterpreter.calculateColor(temp.font_color));

                            double xpos = (properties.zoom * WebsiteInterpreter.calculateValue(temp.x_position));
                            double ypos = (properties.zoom * WebsiteInterpreter.calculateValue(temp.y_position));

                            double maxX = xpos + (properties.zoom * WebsiteInterpreter.calculateValue(temp.width));
                            double maxY = ypos + (properties.zoom * WebsiteInterpreter.calculateValue(temp.height));

                            int index = 0;

                            double ydiff = metrics.getHeight();
                            double textlen = temp.text.length();

                            int italic = 0;
                            int bold = 0;

                            String fontname = temp.font_name;
                            double fontsize = properties.zoom * WebsiteInterpreter.calculateValue(temp.font_size);


                            ypos += ydiff;
                            while (ypos < maxY && index < textlen) {
                                xpos = (properties.zoom * WebsiteInterpreter.calculateValue(temp.x_position)) + 5;
                                while (xpos + 15 < maxX && index < textlen) {

                                    if (temp.text.charAt(index) == '\n') {
                                        index++;
                                        break;
                                    }
                                    else if (temp.text.charAt(index) == '\\') {
                                        index++;
                                        g2.drawString(temp.text.charAt(index) + "", (int) (properties.scrollX + xpos + windowX1), (int) (properties.scrollY + ypos + windowY1));
                                        xpos += metrics.charWidth(temp.text.charAt(index));
                                    }
                                    else if (temp.text.charAt(index) == '<') {
                                        String InsideData = "";
                                        index++;
                                        while (index < textlen && temp.text.charAt(index) != '>') {
                                            InsideData += temp.text.charAt(index);
                                            index++;
                                        }
                                        if (temp.text.charAt(index) == '>' && InsideData.contains(" ")) {
                                            String[] args = InsideData.split(java.util.regex.Matcher.quoteReplacement(" "));
                                            String command = args[0];
                                            String argument = args[1];

                                            // System.out.println("TEST: " + InsideData);

                                            if (command.equals("bold")) {
                                                if (argument.toLowerCase(Locale.ROOT).equals("true"))
                                                    bold = 1;
                                                else if (argument.toLowerCase(Locale.ROOT).equals("false"))
                                                    bold = 0;
                                            }
                                            if (command.equals("italic")) {
                                                if (argument.toLowerCase(Locale.ROOT).equals("true"))
                                                    italic = 1;
                                                else if (argument.toLowerCase(Locale.ROOT).equals("false"))
                                                    italic = 0;
                                            }
                                            if (command.equals("fontname")) {
                                                fontname = argument;
                                            }
                                            if (command.equals("fontsize")) {
                                                fontsize = WebsiteInterpreter.calculateValue(argument);
                                            }


                                            tempFont = new Font(fontname, (Font.ITALIC * italic) + (Font.BOLD * bold), (int) (properties.zoom * fontsize));
                                            metrics = g.getFontMetrics(tempFont);
                                            g2.setFont(tempFont);
                                        }
                                    } else {
                                        g2.drawString(temp.text.charAt(index) + "", (int) (properties.scrollX + xpos + windowX1), (int) (properties.scrollY + ypos + windowY1));
                                        xpos += metrics.charWidth(temp.text.charAt(index));
                                    }
                                    index++;
                                }
                                ypos += ydiff;
                            }

                        }

                        if (!temp.image.equals("")) {
                            if (!temp.image.equals(temp.oldImage)) {
                                temp.oldImage = temp.image;
                                {
                                    Logging.log("Reading Image File: " + temp.image, Logging.logtype.notification);

                                    String path2 = "";


                                    path2 = FileHandler.getPathFromURL(temp.image);

                                    Logging.log("Reading Image File: " + path2, Logging.logtype.notification);

                                    temp.bufferedImage = (new ImageIcon(path2)).getImage();
                                }


                            }

                            {
                                int w = (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.width));
                                int h = (int) (properties.zoom * WebsiteInterpreter.calculateValue(temp.height));

                                if (w < 1)
                                    w = 1;
                                if (h < 1)
                                    h = 1;

                                BufferedImage bufferedImg = toBufferedImage(temp.bufferedImage);


                                BufferedImage after = new BufferedImage(w, h, BufferedImage.TYPE_INT_ARGB);
                                AffineTransform at = new AffineTransform();
                                at.scale(w / (double) bufferedImg.getWidth(), h / (double) bufferedImg.getHeight());
                                AffineTransformOp scaleOp =
                                        new AffineTransformOp(at, AffineTransformOp.TYPE_BILINEAR);
                                after = scaleOp.filter(bufferedImg, after);


                                g2.drawImage(after, null, windowX1 + (int) (properties.scrollX + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.x_position)))), windowY1 + (int) (properties.scrollY + (properties.zoom * (WebsiteInterpreter.calculateValue(temp.y_position)))));
                            }

                            //properties.scrollX+(properties.zoom*())


                        }

                    } else {
                        temp.highlighted = false;
                    }

                }

                if (lasthighlightedindex != -1)
                {
                    WebsiteInterpreter.allBoxes.get(lasthighlightedindex).highlighted = true;
                }



            }



            g2.setColor(colormap.get(cols.background_tabs));
            g2.fillRect(0,0,sizeX, 30);

            g2.setColor(colormap.get(cols.background_main));
            g2.fillRect(0,31,sizeX, 30);

            g2.setColor(colormap.get(cols.seperator_line));
            g2.fillRect(0,30,sizeX, 1);

            g2.setColor(colormap.get(cols.seperator_line));
            g2.fillRect(0,61,sizeX, 1);


            for (int i = 0; i < buttons.size(); i++)
            {
                UI_Button tempButton = buttons.get(i);

                if (tempButton.name.equals("Search Box"))
                {
                    tempButton.width = sizeX - 212;
                }
                else if (tempButton.name.equals("Settings"))
                {
                    tempButton.x = sizeX - 32;
                }


                tempButton.highlighted = (
                        (
                                (mouseX >= tempButton.x + tempButton.padding) && (mouseX < tempButton.x + tempButton.width - tempButton.padding)
                        ) && (
                                (mouseY >= tempButton.y + tempButton.padding) && (mouseY < tempButton.y + tempButton.height - tempButton.padding)
                        )
                );


                if (tempButton.border)
                {
                    g2.setColor(tempButton.border_col);

                    g2.drawRect(tempButton.x, tempButton.y, tempButton.width - 1, tempButton.height - 1);
                }


                if (tempButton.highlighted)
                    g2.setColor(tempButton.highlighted_col);
                else
                    g2.setColor(tempButton.default_col);


                if (tempButton.image == icon.none)
                    g2.fillRect(tempButton.x + tempButton.padding,tempButton.y + tempButton.padding,tempButton.width - (2*tempButton.padding), tempButton.height - (2*tempButton.padding));
                else
                    g2.drawImage(iconmap.get(tempButton.image).getSubimage(tempButton.padding,tempButton.padding, tempButton.width - (2*tempButton.padding), tempButton.height - (2*tempButton.padding)),tempButton.x + tempButton.padding,tempButton.y + tempButton.padding, g2.getColor(), null);

            }




            //g2.setColor(colormap.get(cols.seperator_line));
            //g2.drawLine(30,31,30,60);


            {
                g2.setColor(colormap.get(cols.default_text));
                g2.setFont(new Font("Bahnschrift", 0, 18));
                if (properties.customURL.equals("") || selectedthings.search_bar == selectedThing)
                    g2.drawString(hostname_adress, 158, 52);
                else
                {
                    if (Main.isCurrentURLInternal)
                        g2.drawString(properties.customURL, 158, 52);
                    else
                        g2.drawString(properties.customURL + " - (External Site)", 158, 52);
                }

                if (properties.pageTitle.equals(""))
                    g2.drawString("Website", 5, 22);
                else
                    g2.drawString(properties.pageTitle, 5, 22);
            }


            //g2.drawString("This is gonna be awesome", 70, 20);
            //g2.setColor(colormap.get(cols.default_text));
            //g2.setFont(new Font("Bahnschrift", 0, 20));


            //g2.drawString(toWrite, 30, 100);

            //make a text box to enter adresses into

            //make a browser window

            //make a tab bar

            //make some kind of settings page and stuff






            {
                g2.setColor(colormap.get(cols.seperator_line));
                g2.drawLine(0,0,sizeX - 1,0);
                g2.drawLine(0,sizeY - 1,sizeX,sizeY - 1);

                g2.drawLine(0,0,0,sizeY - 1);
                g2.drawLine(sizeX - 1,0,sizeX - 1,sizeY - 1);
            }


            {
                g2.setColor(Color.red);
                g2.fillRect(mouseX -1, mouseY-1, 3, 3);
            }
        }
    }

    public void update()
    {
        repaint();
    }

    private int count_arr(boolean[] data, boolean match)
    {
        int amount = 0;

        for (int i = 0; i < data.length; i++)
            if (data[i] == match)
                amount++;

        return amount;
    }

}




class MouseDetectionThingy extends JPanel implements MouseListener
{
    public MouseDetectionThingy()
    {
        //addMouseListener(this);
    }
    //Required methods for MouseListener, though the only one you care about is click
    public void mousePressed(MouseEvent e) {}
    public void mouseReleased(MouseEvent e) {}
    public void mouseEntered(MouseEvent e) {}
    public void mouseExited(MouseEvent e) {}

    /** Called whenever the mouse clicks.
     * Could be replaced with setting the value of a JLabel, etc. */
    public void mouseClicked(MouseEvent e) {
        DrawTest.canvas.MouseClickDetection();
        //System.out.println("Mouse Clicked!");
    }
}