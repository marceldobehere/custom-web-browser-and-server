package com.company;

import java.util.ArrayList;
import java.util.List;

public class Main {

    public static String defaultPort;
    public static List<String> allURLs;
    public static int currentURLIndex;
    public static String currentURL;
    public static boolean isCurrentURLInternal;

    public static void main(String[] args) {
        System.out.println("Initialising Logger.");
        Logging.init();

        Logging.log("Starting Webbrowser test", Logging.logtype.normal);
        defaultPort = "1234";
        allURLs = new ArrayList<String>();
        currentURLIndex = -1;


        Logging.log("Initialising Drawing Area", Logging.logtype.normal);
        DrawTest.main();

        Logging.log("Initialising Scripting Interpreter", Logging.logtype.normal);
        ScriptInterpreterManager.init();

        // TO DO:
        // ADD MATH COMMANDS

        // ADD MORE DOCUMENTATION
        // ADD A SETTINGS PAGE AND A CONFIG FILE
        // ADD BOOKMARKS

        // LIMIT THE URL SIZE AND SHORTEN IF NESSESCARY
        // ADD A FULLSCREEN BUTTON OR F11 that also makes the top bar disappear.

        // MAKE COLOURED OUTPUT WORK IN CMD
        // ADD LOGGING TO FILE

        // MAKE A LOGO
        // POTENTIALLY ADD VIDEO / SOUND SUPPORT
        // POTENTIALLY MAKE A HTML/CSS CONVERTER


        Logging.log("Starting Main TCP Thread", Logging.logtype.normal);
        WebsiteInterpreter.initialise();

        Main.currentURL = "!internals/home_page/roml/main.roml";
        //Main.currentURL = "!internals/script_page/roml/main.roml";
        FileHandler.loadWebsiteFromURL();


        Logging.log("Loading Debug Page", Logging.logtype.normal);
        currentURLIndex = -1;


        Logging.log("Drawing Website Frame", Logging.logtype.normal);
        DrawTest.allow_drawing = true;


        Logging.log("Starting Drawing Loop", Logging.logtype.normal);
        while (true)
        {
            DrawTest.canvas.update();

            try
            {
                Thread.sleep(25);
            }
            catch(InterruptedException ex)
            {
                Thread.currentThread().interrupt();
            }
        }
    }
}
