package com.company;

import java.io.IOException;
import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class TCP_Client {
    private Socket socket;

    private String ip;
    private int port;

    public boolean success;

    private PrintWriter writer;
    private BufferedReader reader;

    private InputStream tcp_input;
    private OutputStream tcp_output;

    public TCP_Client(String _ip, int _port)
    {
        success = false;
        Logging.log("Creating new Socket.", Logging.logtype.normal);
        try {
            ip = _ip;
            port = _port;
            socket = new Socket(ip, port);


            tcp_output = socket.getOutputStream();
            writer = new PrintWriter(tcp_output, true);
            tcp_input = socket.getInputStream();
            reader = new BufferedReader(new InputStreamReader(tcp_input));

            //reader.readLine();


            socket.setKeepAlive(true);
            socket.setSoTimeout(1000000);

            success = true;
        } catch (IOException e) {
            Logging.log("Error creating Socket (IO).", Logging.logtype.error);
            //e.printStackTrace();
        } catch (SecurityException e) {
            Logging.log("Error creating Socket (Security).", Logging.logtype.error);
            //e.printStackTrace();
        }
        catch (IllegalArgumentException e) {
            Logging.log("Error creating Socket (Illegal Argument).", Logging.logtype.error);
            //e.printStackTrace();
        }
    }

    public void close()
    {
        if (this.socket == null)
            return;
        Logging.log("Closing Socket.", Logging.logtype.notification);
        try {
            socket.close();
        } catch (IOException e) {
            Logging.log("An Error occured while closing Socket.", Logging.logtype.error);
            //e.printStackTrace();
        }
    }



    public String getFilePathOfServerURL(String url)
    {
        String path = "data/temp/page/" + url;

        File tempFile = new File(path);

        if (!tempFile.exists())
        {
            Logging.log("Sending File request (" + url + ").", Logging.logtype.normal);
            send("GIB_FILE " + url);

            if (receiveFile(path))
            {
                Logging.log("Done.", Logging.logtype.notification);

                return path;
            }
            else
            {
                Logging.log("Error downloading file.", Logging.logtype.error);
                return "";
            }
        }
        return path;
    }



    public void send(String data)
    {
        try
        {
            String tempData = data;
            String processedData = tempData.replaceAll(java.util.regex.Matcher.quoteReplacement("!"),"!!").replaceAll(java.util.regex.Matcher.quoteReplacement("\n"),"!n");
            writer.println(processedData);
        }
        catch (NullPointerException e)
        {
            Logging.log("Error sending Data.", Logging.logtype.error);
        }
    }

    public String receive()
    {
        try {
            String tempData = reader.readLine();
            //System.out.println("temp rec 1: " + tempData);
            String processedData = "";

            if (tempData != null) {
                try {
                    processedData = tempData.replaceAll(java.util.regex.Matcher.quoteReplacement("!n"), "\n").replaceAll(java.util.regex.Matcher.quoteReplacement("!!"), "!");
                } catch (NullPointerException e) {
                    Logging.log("Error receiving Data (3).", Logging.logtype.error);
                }
            }
            else
            {
                Logging.log("Error receiving Data (2).", Logging.logtype.error);
            }
            //System.out.println("temp rec 2: " + processedData);

            return processedData;
        } catch (IOException e) {
            Logging.log("Error receiving Data.", Logging.logtype.error);
            //e.printStackTrace();
        }
        return "";
    }

    public void sendFile(String filepath)
    {
        try {
            File tempFile = new File(filepath);

            if (tempFile.exists())
            {
                Path path = Paths.get(filepath);
                int bytes = (int)Files.size(path);

                send("size: " + bytes);
                if (receive().equals("OK"))
                {
                    byte[] b = new byte[bytes];

                    BufferedInputStream bis = new BufferedInputStream(new FileInputStream(filepath));
                    bis.read(b);

                    tcp_output.write(b,0,bytes);

                    Logging.log("File upload completed", Logging.logtype.notification);
                }
                else {
                    Logging.log("Error sending File.", Logging.logtype.error);

                }
            }
            else
            {
                send("FILE_NOT_FOUND");
            }

        } catch (IOException e) {
            Logging.log("Error sending File.", Logging.logtype.error);

        }
    }

    public boolean receiveFile(String filepath)
    {
        try {
            File file = new File(filepath);
            Files.createDirectories(Paths.get(file.getParent()));

            String sizeString = receive();
            if (sizeString.startsWith("size: "))
            {
                int size = Integer.parseInt(sizeString.substring(sizeString.indexOf(' ') + 1));
                byte[] buffer = new byte[size];

                send("OK");

                tcp_input.read(buffer);

                OutputStream output = new FileOutputStream(filepath);
                output.write(buffer, 0, size);
                output.close();


                Logging.log("Done downloading", Logging.logtype.notification);
                return true;
            }
            else if(sizeString.equals("FILE_NOT_FOUND"))
            {
                Logging.log("Error File not found", Logging.logtype.error);
                return false;
            }

        } catch (IOException e) {
            Logging.log("Error receiving File.", Logging.logtype.error);
            //e.printStackTrace();
        }
        return false;
    }



    public boolean ping()
    {
        send("PING");

        if (receive().equals("PONG"))
            return true;
        else
            return false;
    }


}
