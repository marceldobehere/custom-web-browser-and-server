package com.company;

import javax.swing.*;
import java.awt.*;
import java.awt.desktop.SystemEventListener;
import java.beans.beancontext.BeanContextServiceAvailableEvent;
import java.io.*;
import java.net.Socket;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.rmi.server.LoaderHandler;
import java.time.temporal.ValueRange;
import java.util.*;
import java.util.List;
import java.util.regex.Pattern;

import static java.lang.System.exit;

public class ScriptInterpreterManager
{
    public static List<String> scriptInstanceNames;
    public static List<ScriptInstance> scriptInstances;
    public static Variable[] emptyVariableArr;


    public static void init()
    {
        if (scriptInstances != null)
        {
            stop();
        }
        Logging.log("Resetting/Initialsing Scripts", Logging.logtype.notification);
        emptyVariableArr = new Variable[0];
        scriptInstances = new ArrayList<>();
        scriptInstanceNames = new ArrayList<>();
        inBuiltFunctions.init();

    }

    public static void stop()
    {
        Logging.log("Stopping Scripts", Logging.logtype.notification);
        for (int i = 0; i < scriptInstances.size(); i++)
        {
            scriptInstances.get(i).exit = true;
        }
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            Logging.log("Could not sleep!", Logging.logtype.error);
        }
    }

    public static void addScript(String filepath, boolean launchInit)
    {
        Logging.log("Adding Script", Logging.logtype.notification);
        scriptInstances.add(new ScriptInstance(filepath));

        if (launchInit)
            scriptInstances.get(scriptInstances.size() - 1).CallFunctionFromExternal("init", emptyVariableArr);
    }

    public static void launchInits()
    {
        int size =  scriptInstances.size();
        Logging.log("Launching all init Functions on all loaded Methods.", Logging.logtype.notification);
        for (int i = 0; i < size; i++)
        {
            scriptInstances.get(i).CallFunctionFromExternal("init", emptyVariableArr);
        }
    }
}

class inBuiltFunctions
{
    public static List<String> inbuiltFunctionNames;

    public static void init()
    {
        inbuiltFunctionNames = new ArrayList<>();
        inbuiltFunctionNames.add("print");
        inbuiltFunctionNames.add("read");

        inbuiltFunctionNames.add("string");
        inbuiltFunctionNames.add("int");
        inbuiltFunctionNames.add("double");
        inbuiltFunctionNames.add("bool");

        inbuiltFunctionNames.add("load_script");
        inbuiltFunctionNames.add("call_external_function");
        inbuiltFunctionNames.add("get_path");

        inbuiltFunctionNames.add("get_global");
        inbuiltFunctionNames.add("set_global");

        inbuiltFunctionNames.add("string.length");
        inbuiltFunctionNames.add("string.endswith");
        inbuiltFunctionNames.add("string.startswith");
        inbuiltFunctionNames.add("string.tolower");
        inbuiltFunctionNames.add("string.toupper");
        inbuiltFunctionNames.add("string.contains");
        inbuiltFunctionNames.add("string.indexof");
        inbuiltFunctionNames.add("string.lastindexof");
        inbuiltFunctionNames.add("string.replace");
        inbuiltFunctionNames.add("string.substring");
        inbuiltFunctionNames.add("string.trim");
        inbuiltFunctionNames.add("string.charat.string");
        inbuiltFunctionNames.add("string.charat.int");

        inbuiltFunctionNames.add("stringchar.char_from_ASCII_value");
        inbuiltFunctionNames.add("stringchar.ASCII_value_from_char");

        inbuiltFunctionNames.add("list.create");
        inbuiltFunctionNames.add("list.delete");
        inbuiltFunctionNames.add("list.length");
        inbuiltFunctionNames.add("list.add");
        inbuiltFunctionNames.add("list.insert");
        inbuiltFunctionNames.add("list.remove");
        inbuiltFunctionNames.add("list.get");
        inbuiltFunctionNames.add("list.set");
        inbuiltFunctionNames.add("list.clear");
        inbuiltFunctionNames.add("list.tofile");
        inbuiltFunctionNames.add("list.fromfile");

        inbuiltFunctionNames.add("log");
        inbuiltFunctionNames.add("sleep");
        inbuiltFunctionNames.add("read_popup");

        inbuiltFunctionNames.add("network.socket.send");
        inbuiltFunctionNames.add("network.socket.receive");





    }


    public static Variable executeFunction(String name, Variable[] args)
    {
        if (name.equals("string.contains"))
        {
            if (args.length == 2)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.contains(args[1].STRING));
                else
                    Logging.log("Argument provided to the string.contains function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.contains function!", Logging.logtype.script_error);
        }
        if (name.equals("sleep"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.INT) {
                    try {
                        Thread.sleep(args[0].INT);
                    } catch (InterruptedException e) {
                        Logging.log("Could not sleep!", Logging.logtype.script_error);
                    }
                    return new Variable();
                }
                else
                    Logging.log("Argument provided to the sleep function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the sleep function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.charat.string"))
        {
            if (args.length == 2)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.INT) {
                    try{
                        return new Variable((args[0].STRING.charAt(args[1].INT) + ""));
                    }
                    catch(IndexOutOfBoundsException ex)
                    {
                        Logging.log("string.charat.string had an IndexOutOfBoundsException!", Logging.logtype.script_error);
                        return new Variable("");
                    }
                }
                else
                    Logging.log("Argument provided to the string.charat.string function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.charat.string function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.charat.int"))
        {
            if (args.length == 2)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.INT) {
                    try{
                        return new Variable((int)(args[0].STRING.charAt(args[1].INT)));
                    }
                    catch(IndexOutOfBoundsException ex)
                    {
                        Logging.log("string.charat.int had an IndexOutOfBoundsException!", Logging.logtype.script_error);
                        return new Variable(0);
                    }
                }
                else
                    Logging.log("Argument provided to the string.charat.int function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.charat.int function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.endswith"))
        {
            if (args.length == 2)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.endsWith(args[1].STRING));
                else
                    Logging.log("Argument provided to the string.endswith function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.endswith function!", Logging.logtype.script_error);
        }
        else if (name.equals("stringchar.char_from_ASCII_value"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.INT) {
                    int temp = args[0].INT;
                    return new Variable(("" + ((char)temp)));
                }
                else
                    Logging.log("Argument provided to the stringchar.char_from_ASCII_value function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the stringchar.char_from_ASCII_value function!", Logging.logtype.script_error);
        }
        else if (name.equals("stringchar.ASCII_value_from_char"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.STRING) {
                    if (args[0].STRING.length() == 1)
                    {
                        int temp = args[0].STRING.charAt(0);
                        return new Variable(temp);
                    }
                    else
                        Logging.log("String provided to the stringchar.ASCII_value_from_char function is not 1 char long", Logging.logtype.script_error);
                }
                else
                    Logging.log("Argument provided to the stringchar.ASCII_value_from_char function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the stringchar.ASCII_value_from_char function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.startswith"))
        {
            if (args.length == 2)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.startsWith(args[1].STRING));
                else
                    Logging.log("Argument provided to the string.startswith function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.startswith function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.indexof"))
        {
            if (args.length == 2)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.indexOf(args[1].STRING));
                else
                    Logging.log("Argument provided to the string.indexof function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.indexof function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.tolower"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.toLowerCase());
                else
                    Logging.log("Argument provided to the string.tolower function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.tolower function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.toupper"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.toUpperCase());
                else
                    Logging.log("Argument provided to the string.toupper function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.toupper function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.trim"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.trim());
                else
                    Logging.log("Argument provided to the string.trim function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.trim function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.lastindexof"))
        {
            if (args.length == 2)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.lastIndexOf(args[1].STRING));
                else
                    Logging.log("Argument provided to the string.lastindexof function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.lastindexof function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.replace"))
        {
            if (args.length == 3)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING && args[2].varType == Variable.type.STRING)
                    return new Variable(args[0].STRING.replace(args[1].STRING, args[2].STRING));
                else
                    Logging.log("Argument provided to the string.replace function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.replace function!", Logging.logtype.script_error);
        }
        else if (name.equals("string.substring"))
        {
            if (args.length == 3)
            {
                if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.INT && args[2].varType == Variable.type.INT) {
                    try{
                        return new Variable(args[0].STRING.substring(args[1].INT, args[2].INT + 1));
                    }
                    catch(IndexOutOfBoundsException ex)
                    {
                        Logging.log("string.substring had an IndexOutOfBoundsException!", Logging.logtype.script_error);
                        return new Variable("");
                    }
                }
                else
                    Logging.log("Argument provided to the string.substring function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.substring function!", Logging.logtype.script_error);
        }
        else if (name.equals("call_external_function"))
        {
            if (args.length >= 2)
            {
                String path = executeFunction("string",new Variable[] {args[0]}).STRING;
                String functionName = executeFunction("string",new Variable[] {args[1]}).STRING;

                if (ScriptInterpreterManager.scriptInstanceNames.contains(path))
                {
                    int index = ScriptInterpreterManager.scriptInstanceNames.indexOf(path);

                    Variable[] args2 = new Variable[args.length - 2];

                    for (int i = 0; i < args2.length; i++)
                        args2[i] = args[i + 2];

                    if (ScriptInterpreterManager.scriptInstances.get(index).functions.containsKey(functionName))
                    {
                        return ScriptInterpreterManager.scriptInstances.get(index).CallFunctionFromInternal(functionName, args2);
                    }
                    else
                    {
                        Logging.log("Function \"" + functionName + "\" was not found or loaded!", Logging.logtype.script_error);
                        return new Variable();
                    }
                }
                else
                {
                    Logging.log("Script \"" + path + "\" was not found or loaded!", Logging.logtype.script_error);
                    return new Variable();
                }
            }
            else
            {
                Logging.log("Argument list incompatible with call_external_function function!", Logging.logtype.script_error);
                return new Variable();
            }

        }
        else if (name.equals("load_script"))
        {
            if (args.length == 2)
            {
                String path = executeFunction("string",new Variable[] {args[0]}).STRING;
                boolean launchInit = executeFunction("bool",new Variable[] {args[1]}).BOOL;

                ScriptInterpreterManager.addScript(path, launchInit);

                return new Variable();
            }
            else
            {
                Logging.log("Argument list incompatible with the load_script function!", Logging.logtype.script_error);
                return new Variable();
            }

        }
        else if (name.equals("get_path"))
        {
            if (args.length == 1)
            {
                return new Variable(executeFunction("string",new Variable[] {args[0]}).STRING);
            }
            else
            {
                Logging.log("Argument list incompatible with the get_path function!", Logging.logtype.script_error);
                return new Variable();
            }

        }
        else if (name.equals("get_global"))
        {
            if (args.length == 2)
            {
                String path = args[0].STRING;
                String varnName = args[1].STRING;

                if (ScriptInterpreterManager.scriptInstanceNames.contains(path))
                {
                    int index = ScriptInterpreterManager.scriptInstanceNames.indexOf(path);

                    if (ScriptInterpreterManager.scriptInstances.get(index).globalVars.containsKey(varnName))
                    {
                        return ScriptInterpreterManager.scriptInstances.get(index).globalVars.get(varnName);
                    }
                    else
                    {
                        Logging.log("Variable \"" + varnName + "\" was not found!", Logging.logtype.script_error);
                        return new Variable();
                    }
                }
                else
                {
                    Logging.log("Script \"" + path + "\" was not found or loaded!", Logging.logtype.script_error);
                    return new Variable();
                }
            }
            else
            {
                Logging.log("Argument list incompatible with get_global function!", Logging.logtype.script_error);
                return new Variable();
            }

        }
        else if (name.equals("set_global"))
        {
            if (args.length == 3)
            {
                String path = args[0].STRING;
                String varnName = args[1].STRING;

                if (ScriptInterpreterManager.scriptInstanceNames.contains(path))
                {
                    int index = ScriptInterpreterManager.scriptInstanceNames.indexOf(path);

                    if (ScriptInterpreterManager.scriptInstances.get(index).globalVars.containsKey(varnName))
                    {
                        ScriptInterpreterManager.scriptInstances.get(index).globalVars.put(varnName, args[2]);
                        return new Variable();
                    }
                    else
                    {
                        Logging.log("Variable \"" + varnName + "\" was not found!", Logging.logtype.script_error);
                        return new Variable();
                    }
                }
                else
                {
                    Logging.log("Script \"" + path + "\" was not found or loaded!", Logging.logtype.script_error);
                    return new Variable();
                }
            }
            else
            {
                Logging.log("Argument list incompatible with set_global function!", Logging.logtype.script_error);
                return new Variable();
            }

        }
        else if (name.equals("string.length"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.STRING)
                {
                    return new Variable(args[0].STRING.length());
                }
                else
                    Logging.log("Argument provided to the string.length function is not a String!", Logging.logtype.script_error);
            }
            else
                Logging.log("Argument list incompatible with the string.length function!", Logging.logtype.script_error);
        }
        else if (name.equals("print"))
        {
            if (args.length == 1)
            {
                String temp = "";
                if (args[0].varType == Variable.type.STRING)
                    temp = args[0].STRING;
                else
                    temp = executeFunction("string",args).STRING;


                Logging.log(temp, Logging.logtype.script_output);
                return new Variable();
            }
            else
                Logging.log("Argument list incompatible with the print function!", Logging.logtype.script_error);
        }
        else if (name.equals("log"))
        {
            if (args.length == 2)
            {
                String temp = "";
                if (args[0].varType == Variable.type.STRING)
                    temp = args[0].STRING;
                else
                    temp = executeFunction("string",args).STRING;


                StringBuilder temp2 = new StringBuilder();

                for (int i = 0; i < temp.length(); i++)
                {
                    if (temp.charAt(i) == '\\')
                    {
                        if (i + 1 < temp.length())
                        {
                            if (temp.charAt(i + 1) == '\\')
                            {
                                temp2.append('\\');
                                i += 1;
                                continue;
                            }
                            else if (temp.charAt(i + 1) == '\"')
                            {
                                temp2.append('\"');
                                i += 1;
                                continue;
                            }
                            else if (temp.charAt(i + 1) == 'n')
                            {
                                temp2.append('\n');
                                i += 1;
                                continue;
                            }
                        }
                        else
                            Logging.log("Invalid Escape Sequence", Logging.logtype.script_error);
                    }
                    temp2.append(temp.charAt(i));
                }

                Logging.logtype temptype = Logging.logtype.in_script_normal;

                String tempString = args[1].STRING;

                if (tempString.equals("normal"))
                    temptype = Logging.logtype.in_script_normal;
                else if (tempString.equals("notification"))
                    temptype = Logging.logtype.in_script_notification;
                else if (tempString.equals("warning"))
                    temptype = Logging.logtype.in_script_warning;
                else if (tempString.equals("error"))
                    temptype = Logging.logtype.in_script_error;
                else
                    Logging.log("Invalid Script Type given!", Logging.logtype.script_error);

                Logging.log(temp2.toString(), temptype);
                return new Variable();
            }
            else
                Logging.log("Argument list incompatible with the print function!", Logging.logtype.script_error);
        }
        else if (name.equals("string"))
        {
            if (args.length == 1) {

                String data = "";
                //Logging.log("Converting Variable Type \"" + args[0].varType + "\" to String.", Logging.logtype.script_error);

                if (args[0].varType == Variable.type.STRING)
                    data = args[0].STRING;
                else if (args[0].varType == Variable.type.INT)
                    data = args[0].INT + "";
                else if (args[0].varType == Variable.type.DOUBLE)
                    data = args[0].DOUBLE + "";
                else if (args[0].varType == Variable.type.BOOL) {
                    if (args[0].BOOL)
                        data = "true";
                    else
                        data = "false";
                }
                else if (args[0].varType == Variable.type.VOID)
                    data = "";
                else
                    Logging.log("cannot convert Variable Type \"" + args[0].varType + "\" to String.", Logging.logtype.script_error);

                return new Variable(data);
            }
            else {
                Logging.log("Argument list incompatible with the string function!", Logging.logtype.script_error);
                return new Variable();
            }
        }
        else if (name.equals("int"))
        {
            if (args.length == 1) {
                if (args[0].varType == Variable.type.DOUBLE)
                    return new Variable((int)args[0].DOUBLE);
                else
                    return new Variable(Integer.parseInt(executeFunction("string", args).STRING));
            }
            else {
                Logging.log("Argument list incompatible with the int function!", Logging.logtype.script_error);
                return new Variable();
            }
        }
        else if (name.equals("read"))
        {
            if (args.length == 0)
            {
                BufferedReader reader = new BufferedReader(
                        new InputStreamReader(System.in));
                System.out.print("> ");
                try {
                    return new Variable(reader.readLine());
                } catch (IOException e) {
                    Logging.log("Error receiving User Input.", Logging.logtype.error);
                    return new Variable("");
                }
            }
            else {
                Logging.log("Argument list incompatible with the read function!", Logging.logtype.script_error);
                return new Variable();
            }
        }
        //JOptionPane.showInputDialog("Enter a path")
        else if (name.equals("read_popup"))
        {
            if (args.length == 1)
            {
                if (args[0].varType == Variable.type.STRING )
                    return new Variable(JOptionPane.showInputDialog(args[0].STRING));
                else
                Logging.log("Argument provided to the read_popup function is not a String!", Logging.logtype.script_error);
            }
            else {
                Logging.log("Argument list incompatible with the read_popup function!", Logging.logtype.script_error);
                return new Variable();
            }
        }
        else if (name.equals("double"))
        {
            if (args.length == 1)
                return new Variable(Double.parseDouble(executeFunction("string",args).STRING));
            else {
                Logging.log("Argument list incompatible with the double function!", Logging.logtype.script_error);
                return new Variable();
            }
        }
        else if (name.equals("bool"))
        {
            if (args.length == 1) {
                String data = executeFunction("string",args).STRING;

                if (data.equals("true"))
                    return new Variable(true);
                else if (data.equals("false"))
                    return new Variable(false);
                else
                {
                    Logging.log("Could not Convert \"" + data + "\" to boolean!", Logging.logtype.script_error);
                }

            }
            else {
                Logging.log("Argument list incompatible with the bool function!", Logging.logtype.script_error);
                return new Variable();
            }
        }


        Logging.log("intern Function \"" + name + "\" not found!", Logging.logtype.script_error);
        return new Variable();
    }

}


class ScriptInstance
{
    public String filepath;
    public Map<String, Variable> globalVars;
    public Map<String, Function> functions;
    public List<IFStatement> ifs;
    public List<WhileStatement> whiles;
    public List<String> scriptLines;
    public Map<String, ListThing> lists;
    public Map<String, NetworkThing> networks;
    public boolean exit;


    public ScriptInstance(String filepath)
    {
        this.filepath = filepath;
        globalVars = new Hashtable<>();
        functions = new Hashtable<>();
        scriptLines = new ArrayList<>();
        ifs = new ArrayList<>();
        whiles = new ArrayList<>();
        lists = new Hashtable<>();
        networks = new Hashtable<>();
        exit = false;
        LoadAndCompile(filepath);



    }


    public void CallFunctionFromExternal(String name, Variable[] args)
    {
        if (inBuiltFunctions.inbuiltFunctionNames.contains(name))
            inBuiltFunctions.executeFunction(name, args);
        else {
            if (functions.containsKey(name))
            {
                new RunFunc(functions.get(name), args).start();
            }
            else
            {
                Logging.log("Function \"" + name + "\" was not found!", Logging.logtype.script_error);
            }
        }
    }

    public Variable CallFunctionFromInternal(String name, Variable[] args)
    {
        if (inBuiltFunctions.inbuiltFunctionNames.contains(name))
        {
            Variable _return = executeTempFunction(name, args);
            if (_return != null)
                return _return;
            else
                return inBuiltFunctions.executeFunction(name, args);

        }
        else
        {
            if (functions.containsKey(name))
            {
                RunFunc temp = new RunFunc(functions.get(name), args);

                return temp.execute();
            }
            else
            {
                Logging.log("Function \"" + name + "\" was not found!", Logging.logtype.script_error);
                return new Variable();
            }
        }
    }

    public Variable executeTempFunction(String name, Variable[] args)
    {
        if (name.startsWith("list."))
        {
            if (args.length < 1)
            {
                Logging.log("Invalid Arguments passed for list function!", Logging.logtype.script_error);
                return new Variable();
            }


            if (name.equals("list.create")) {
                if (args.length == 1) {
                    if (args[0].varType == Variable.type.STRING) {
                        lists.put(args[0].STRING, new ListThing());
                        return new Variable();
                    }
                }

                Logging.log("Invalid Arguments passed for list.create function!", Logging.logtype.script_error);
                return new Variable();
            }
            else if (name.equals("list.tofile")) {
                if (args.length == 2) {
                    if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING) {

                        File writeFile = new File(args[1].STRING);
                        try {
                            Files.createDirectories(Paths.get(writeFile.getParent()));

                            if (lists.containsKey(args[0].STRING))
                            {
                                ListThing temp = lists.get(args[0].STRING);

                                FileWriter fw = new FileWriter(writeFile);

                                for (int i = 0; i < temp.list.size(); i++) {
                                    fw.write(inBuiltFunctions.executeFunction("string", new Variable[] {temp.list.get(i)}).STRING);
                                    if ((i + 1) < temp.list.size())
                                        fw.write("\n");
                                }

                                fw.close();
                            }
                            else
                            {
                                Logging.log("List could not be found!", Logging.logtype.script_error);
                            }


                        } catch (IOException e) {
                            Logging.log("Could not create File!", Logging.logtype.error);
                        }


                        //lists.put(args[0].STRING, new ListThing());
                        return new Variable();
                    }
                }

                Logging.log("Invalid Arguments passed for list.tofile function!", Logging.logtype.script_error);
                return new Variable();
            }
            else if (name.equals("list.fromfile")) {
                if (args.length == 2) {
                    if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING) {

                        try(BufferedReader br = new BufferedReader(new FileReader(args[1].STRING))) {
                            if (lists.containsKey(args[0].STRING))
                            {
                                ListThing temp = lists.get(args[0].STRING);
                                temp.list = new ArrayList<>();

                                for(String line; (line = br.readLine()) != null; ) {
                                    temp.list.add(new Variable(line));
                                }
                            }
                            else
                            {
                                Logging.log("List could not be found!", Logging.logtype.script_error);
                            }
                            // line is not visible here.
                        } catch (FileNotFoundException e) {
                            Logging.log("File could not be found!", Logging.logtype.error);
                            exit(-1);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }

                        //lists.put(args[0].STRING, new ListThing());
                        return new Variable();
                    }
                }

                Logging.log("Invalid Arguments passed for list.fromfile function!", Logging.logtype.script_error);
                return new Variable();
            }
            else if (name.equals("list.delete")) {
                if (args.length == 1) {
                    if (args[0].varType == Variable.type.STRING) {
                        lists.remove(args[0].STRING);
                        return new Variable();
                    }
                }

                Logging.log("Invalid Arguments passed for list.delete function!", Logging.logtype.script_error);
                return new Variable();
            }
            if (!lists.containsKey(args[0].STRING))
            {
                Logging.log("List doesn't contain given Listname", Logging.logtype.script_error);
                return new Variable();
            }
            if (name.equals("list.length")) {
                if (args.length == 1) {
                    if (args[0].varType == Variable.type.STRING) {
                        return new Variable(lists.get(args[0].STRING).list.size());
                    }
                }

                Logging.log("Invalid Arguments passed for list.length function!", Logging.logtype.script_error);
                return new Variable();
            } else if (name.equals("list.clear")) {
                if (args.length == 1) {
                    if (args[0].varType == Variable.type.STRING) {
                        lists.get(args[0].STRING).list.clear();
                        return new Variable();
                    }
                }

                Logging.log("Invalid Arguments passed for list.length function!", Logging.logtype.script_error);
                return new Variable();
            } else if (name.equals("list.add")) {
                if (args.length == 2) {
                    if (args[0].varType == Variable.type.STRING) {
                        if (lists.get(args[0].STRING) != null) {
                            lists.get(args[0].STRING).list.add(args[1]);
                            return new Variable();
                        } else {
                            Logging.log("List not found in list.add function!", Logging.logtype.script_error);
                        }
                    }
                }

                Logging.log("Invalid Arguments passed for list.add function!", Logging.logtype.script_error);
                return new Variable();
            } else if (name.equals("list.insert")) {
                if (args.length == 3) {
                    if (args[0].varType == Variable.type.STRING && args[2].varType == Variable.type.INT) {
                        if (lists.get(args[0].STRING) != null) {
                            try {
                                lists.get(args[0].STRING).list.add(args[2].INT, args[1]);
                                return new Variable();
                            } catch (IndexOutOfBoundsException ex) {
                                Logging.log("Index out of Bounds for the list!", Logging.logtype.script_error);
                            }
                        } else {
                            Logging.log("List not found in list.insert function!", Logging.logtype.script_error);
                        }
                    }
                }

                Logging.log("Invalid Arguments passed for list.insert function!", Logging.logtype.script_error);
                return new Variable();
            } else if (name.equals("list.remove")) {
                if (args.length == 2) {
                    if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.INT) {
                        if (lists.get(args[0].STRING) != null) {
                            try {
                                lists.get(args[0].STRING).list.remove(args[1].INT);
                                return new Variable();
                            } catch (IndexOutOfBoundsException ex) {
                                Logging.log("Index out of Bounds for the list!", Logging.logtype.script_error);
                            }
                        } else {
                            Logging.log("List not found in list.remove function!", Logging.logtype.script_error);
                        }
                    }
                }

                Logging.log("Invalid Arguments passed for list.remove function!", Logging.logtype.script_error);
                return new Variable();
            } else if (name.equals("list.set")) {
                if (args.length == 3) {
                    if (args[0].varType == Variable.type.STRING && args[2].varType == Variable.type.INT) {
                        if (lists.get(args[0].STRING) != null) {
                            try {
                                lists.get(args[0].STRING).list.set(args[2].INT, args[1]);
                                return new Variable();
                            } catch (IndexOutOfBoundsException ex) {
                                Logging.log("Index out of Bounds for the list!", Logging.logtype.script_error);
                            }
                        } else {
                            Logging.log("List not found in list.set function!", Logging.logtype.script_error);
                        }
                    }
                }

                Logging.log("Invalid Arguments passed for list.set function!", Logging.logtype.script_error);
                return new Variable();
            } else if (name.equals("list.get")) {
                if (args.length == 2) {
                    if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.INT) {
                        if (lists.get(args[0].STRING) != null) {
                            try {
                                return lists.get(args[0].STRING).list.get(args[1].INT);
                            } catch (IndexOutOfBoundsException ex) {
                                Logging.log("Index out of Bounds for the list!", Logging.logtype.script_error);
                            }
                        } else {
                            Logging.log("List not found in list.get function!", Logging.logtype.script_error);
                        }
                    }
                }

                Logging.log("Invalid Arguments passed for list.get function!", Logging.logtype.script_error);
                return new Variable();
            }
        }
        else if (name.startsWith("network."))
        {
            if (args.length < 1) {
                Logging.log("Invalid Arguments passed for network function!", Logging.logtype.script_error);
                return new Variable();
            }


            if (name.equals("network.socket.receive")) {
                if (args.length == 1) {
                    if (args[0].varType == Variable.type.STRING) {
                        return new Variable(networks.get(args[0].STRING).receive());
                    }
                }

                Logging.log("Invalid Arguments passed for network.socket.receive function!", Logging.logtype.script_error);
                return new Variable();
            }
            else if (name.equals("network.socket.send")) {
                if (args.length == 2) {
                    if (args[0].varType == Variable.type.STRING && args[1].varType == Variable.type.STRING) {
                        return new Variable(networks.get(args[0].STRING).send(args[1].STRING));
                    }
                }

                Logging.log("Invalid Arguments passed for network.socket.send function!", Logging.logtype.script_error);
                return new Variable();
            }
        }

            return null;
    }


    public void LoadAndCompile(String filepath)
    {
        String filename = filepath;

        ScriptInterpreterManager.scriptInstanceNames.add(filepath);

        Logging.log("Reading Script File.", Logging.logtype.notification);
        // open file to read
        File tempfile = new File(filename);

        if (!tempfile.exists())
        {
            Logging.log("Script File doesn't exist", Logging.logtype.error);
            return;
        }

        scriptLines = new ArrayList<>();


        try(BufferedReader br = new BufferedReader(new FileReader(filename))) {
            for(String line; (line = br.readLine()) != null; ) {
                String templine = line.trim();
                if (templine.length() != 0 && !templine.startsWith("//"))
                    scriptLines.add(line.trim());
            }
            // line is not visible here.
        } catch (IOException e) {
            //e.printStackTrace();
            Logging.log("Error while reading File", Logging.logtype.error);
        }

        for (int i = 0; i < scriptLines.size(); i++)
        {
            //Logging.log("Line " + i + ": " + scriptLines.get(i), Logging.logtype.script_notification);
        }

        //Logging.log("----------------", Logging.logtype.notification);

        for (int i = 0; i < scriptLines.size(); i++)
        {
            if (scriptLines.get(i).startsWith("if"))
            {
                int tempI = i;
                if ((i + 1 < scriptLines.size()))
                {
                    if (scriptLines.get(i + 1).equals("{"))
                    {
                        int IFStart = i + 1;

                        {
                            int layer = 0;
                            do {
                                i++;
                                //System.out.println("B " + layer + " A " + i);
                                if (scriptLines.get(i).equals("{"))
                                    layer++;
                                if (scriptLines.get(i).equals("}"))
                                    layer--;
                            } while (layer != 0 && i < scriptLines.size());
                        }
                        if (i < scriptLines.size())
                        {
                            int IFEnd = i;
                            int ELSEStart = IFEnd;
                            int ELSEEnd = IFEnd;

                            if ((i + 1) < scriptLines.size())
                            {
                                if (scriptLines.get(i + 1).startsWith("else"))
                                {
                                    i++;
                                    ELSEStart = i + 1;

                                    {
                                        int layer = 0;
                                        do {
                                            i++;
                                            //System.out.println("B " + layer + " A " + i);
                                            if (scriptLines.get(i).equals("{"))
                                                layer++;
                                            if (scriptLines.get(i).equals("}"))
                                                layer--;
                                        } while (layer != 0 && i < scriptLines.size());
                                    }
                                    if (i < scriptLines.size())
                                    {
                                        ELSEEnd = i;
                                    }
                                    else
                                    {
                                        Logging.log("ELSE NOT ENDED!", Logging.logtype.script_error);
                                    }
                                }
                            }

                            ifs.add(new IFStatement(IFStart, IFEnd, ELSEStart, ELSEEnd, IFStart - 1));
                        }
                    }
                }
                i = tempI;
            }
            else if (scriptLines.get(i).startsWith("while"))
            {
                int tempI = i;
                if ((i + 1 < scriptLines.size()))
                {
                    if (scriptLines.get(i + 1).equals("{"))
                    {
                        int whileStart = i + 1;

                        {
                            int layer = 0;
                            do {
                                i++;
                                //System.out.println("B " + layer + " A " + i);
                                if (scriptLines.get(i).equals("{"))
                                    layer++;
                                if (scriptLines.get(i).equals("}"))
                                    layer--;
                            } while (layer != 0 && i < scriptLines.size());
                        }
                        if (i < scriptLines.size())
                        {
                            int whileEnd = i;

                            whiles.add(new WhileStatement(whileStart, whileEnd, whileStart - 1));
                        }
                    }
                }
                i = tempI;
            }
        }


        for (int i = 0; i < scriptLines.size(); i++)
        {
            if (scriptLines.get(i).startsWith("func "))
            {
                if ((i + 1 < scriptLines.size()))
                {
                    if (scriptLines.get(i + 1).equals("{"))
                    {
                        int layer = 0;
                        int startIndex = i + 1;
                        //System.out.println("A " + lines.size());
                        do
                        {
                            i++;
                            //System.out.println("B " + layer + " A " + i);
                            if (scriptLines.get(i).equals("{"))
                                layer++;
                            if (scriptLines.get(i).equals("}"))
                                layer--;
                        } while (layer != 0 && i < scriptLines.size());
                        if (i < scriptLines.size())
                        {
                            int endIndex = i;

                            String funcLine = scriptLines.get(startIndex - 1);

                            String funcName = "";
                            List<String> funcArgumentNames = new ArrayList<>();
                            List<Variable.type> funcArgumentVars = new ArrayList<>();

                            Variable.type returnType = Variable.type.NONE;

                            String[] funcText = funcLine.substring(0, funcLine.indexOf('(')).trim().split(java.util.regex.Matcher.quoteReplacement(" "));

                            returnType = Variable.parseType(funcText[1]);
                            funcName = funcText[2];

                            String argText = funcLine.substring(funcLine.indexOf('(') + 1, funcLine.length() - 1);
                            //System.out.println("AAA: " + argText);
                            if (!argText.equals(""))
                            {
                                String[] argsSplit = argText.split(java.util.regex.Matcher.quoteReplacement(","));
                                for (int i2 = 0; i2 < argsSplit.length; i2++)
                                {
                                    //System.out.println("BBB: " + argsSplit[i2]);
                                    String[] varSplit = argsSplit[i2].trim().split(java.util.regex.Matcher.quoteReplacement(" "));
                                    Variable.type varType = Variable.parseType(varSplit[0]);
                                    String varName = varSplit[1];
                                    funcArgumentNames.add(varName);
                                    funcArgumentVars.add(varType);
                                }
                            }

                            functions.put(funcName, new Function(funcName, startIndex, endIndex, funcArgumentNames, funcArgumentVars, returnType));
                        }
                    }
                }
            }
        }


        //Logging.log("----------------", Logging.logtype.notification);

    }




    class RunFunc implements Runnable {
        private Thread t;
        private Function func;
        private Map<String, Variable> localVars;
        private int index;

        private void addVar(String varname, Variable.type type, boolean global)
        {
            if (global)
                globalVars.put(varname, new Variable(type));
            else
                localVars.put(varname, new Variable(type));
        }
        private void addVar(String varname, Variable.type type)
        {
            addVar(varname, type, false);
        }

        public void setVar(String varname, Variable data)
        {
            Variable toSet = getVar(varname);
            if (toSet.varType == data.varType)
            {
                if (toSet.varType == Variable.type.STRING)
                    toSet.STRING = data.STRING;
                else if (toSet.varType == Variable.type.INT)
                    toSet.INT = data.INT;
                else if (toSet.varType == Variable.type.DOUBLE)
                    toSet.DOUBLE = data.DOUBLE;
                else if (toSet.varType == Variable.type.BOOL)
                    toSet.BOOL = data.BOOL;
            }
            else
            {
                Logging.log("Variables \"" + varname + "\" (" + toSet.varType +") doesn't macht type " + data.varType + " of other variable.", Logging.logtype.script_error);
            }
        }

        public Variable getVar(String varname)
        {
            if (localVars.containsKey(varname))
            {
                return localVars.get(varname);
            }
            else if (globalVars.containsKey(varname))
            {
                return globalVars.get(varname);
            }
            else
            {
                Logging.log("Variable \"" + varname + "\" not found!", Logging.logtype.script_error);
            }
            return null;
        }


        RunFunc(Function func, Variable[] args) {
            localVars = new HashMap<>();
            this.func = func;
            //Logging.log("Preparing \"" + func.funcName + "\" Function.", Logging.logtype.script_notification);
            //funcArgs = args;
            index = func.startIndex + 1;

            {
                for (int i = 0; i < func.funcArgumentNames.size(); i++)
                {
                    //Logging.log(" - 2 Variable \"" + func.funcArgumentNames.get(i) + "\" (type: " + func.funcArgumentVars.get(i) + ").", Logging.logtype.script_notification);
                    addVar(func.funcArgumentNames.get(i), func.funcArgumentVars.get(i));
                    setVar(func.funcArgumentNames.get(i), args[i]);
                }

            }

        }


        public Variable doMath (Variable a, String op, Variable b)
        {
            if (a.varType == Variable.type.STRING)
            {
                if (b.varType == Variable.type.STRING)
                {
                    if (op.equals("+"))
                    {
                        a.STRING += b.STRING;
                        return a;
                    }
                    else if (op.equals("=="))
                    {
                        return new Variable(a.STRING.equals(b.STRING));
                    }
                    else if (op.equals("!="))
                    {
                        return new Variable(!a.STRING.equals(b.STRING));
                    }
                }
                if (b.varType == Variable.type.INT)
                {
                    if (op.equals("+"))
                    {
                        a.STRING += b.INT;
                        return a;
                    }
                }
                if (b.varType == Variable.type.DOUBLE)
                {
                    if (op.equals("+"))
                    {
                        a.STRING += b.DOUBLE;
                        return a;
                    }
                }
            }
            else if (a.varType == Variable.type.INT)
            {
                if (b.varType == Variable.type.INT)
                {
                    if (op.equals("+"))
                    {
                        a.INT += b.INT;
                        return a;
                    }
                    else if (op.equals("-"))
                    {
                        a.INT -= b.INT;
                        return a;
                    }
                    if (op.equals("*"))
                    {
                        a.INT *= b.INT;
                        return a;
                    }
                    else if (op.equals("/"))
                    {
                        a.INT /= b.INT;
                        return a;
                    }
                    else if (op.equals("=="))
                        return new Variable(a.INT == b.INT);
                    else if (op.equals("!="))
                        return new Variable(a.INT != b.INT);
                    else if (op.equals(">="))
                        return new Variable(a.INT >= b.INT);
                    else if (op.equals("<="))
                        return new Variable(a.INT <= b.INT);
                    else if (op.equals(">"))
                        return new Variable(a.INT > b.INT);
                    else if (op.equals("<"))
                        return new Variable(a.INT < b.INT);
                }
                else if (b.varType == Variable.type.DOUBLE)
                {
                    if (op.equals("+"))
                    {
                        b.DOUBLE += a.INT;
                        return b;
                    }
                    else if (op.equals("-"))
                    {
                        b.DOUBLE -= a.INT;
                        return b;
                    }
                    if (op.equals("*"))
                    {
                        b.DOUBLE *= a.INT;
                        return b;
                    }
                    else if (op.equals("/"))
                    {
                        b.DOUBLE /= a.INT;
                        return b;
                    }
                    else if (op.equals(">="))
                        return new Variable(a.INT >= b.DOUBLE);
                    else if (op.equals("<="))
                        return new Variable(a.INT <= b.DOUBLE);
                    else if (op.equals(">"))
                        return new Variable(a.INT > b.DOUBLE);
                    else if (op.equals("<"))
                        return new Variable(a.INT < b.DOUBLE);

                }
                else if (b.varType == Variable.type.STRING)
                {
                    if (op.equals("+"))
                    {
                        b.STRING += a.INT;
                        return b;
                    }
                }
            }
            else if (a.varType == Variable.type.DOUBLE)
            {
                if (b.varType == Variable.type.INT)
                {
                    if (op.equals("+"))
                    {
                        a.DOUBLE += b.INT;
                        return a;
                    }
                    else if (op.equals("-"))
                    {
                        a.DOUBLE -= b.INT;
                        return a;
                    }
                    if (op.equals("*"))
                    {
                        a.DOUBLE *= b.INT;
                        return a;
                    }
                    else if (op.equals("/"))
                    {
                        a.DOUBLE /= b.INT;
                        return a;
                    }
                    else if (op.equals(">="))
                        return new Variable(a.DOUBLE >= b.INT);
                    else if (op.equals("<="))
                        return new Variable(a.DOUBLE <= b.INT);
                    else if (op.equals(">"))
                        return new Variable(a.DOUBLE > b.INT);
                    else if (op.equals("<"))
                        return new Variable(a.DOUBLE < b.INT);

                }
                else if (b.varType == Variable.type.DOUBLE)
                {
                    if (op.equals("+"))
                    {
                        a.DOUBLE += b.DOUBLE;
                        return a;
                    }
                    else if (op.equals("-"))
                    {
                        a.DOUBLE -= b.DOUBLE;
                        return a;
                    }
                    if (op.equals("*"))
                    {
                        a.DOUBLE *= b.DOUBLE;
                        return a;
                    }
                    else if (op.equals("/"))
                    {
                        a.DOUBLE /= b.DOUBLE;
                        return a;
                    }
                    else if (op.equals("=="))
                        return new Variable(a.DOUBLE == b.DOUBLE);
                    else if (op.equals("!="))
                        return new Variable(a.DOUBLE != b.DOUBLE);
                    else if (op.equals(">="))
                        return new Variable(a.DOUBLE >= b.DOUBLE);
                    else if (op.equals("<="))
                        return new Variable(a.DOUBLE <= b.DOUBLE);
                    else if (op.equals(">"))
                        return new Variable(a.DOUBLE > b.DOUBLE);
                    else if (op.equals("<"))
                        return new Variable(a.DOUBLE < b.DOUBLE);
                }
                else if (b.varType == Variable.type.STRING)
                {
                    if (op.equals("+"))
                    {
                        b.STRING += a.DOUBLE;
                        return b;
                    }
                }
            }
            else if (a.varType == Variable.type.BOOL)
            {
                if (b.varType == Variable.type.BOOL)
                {
                    if (op.equals("=="))
                    {
                        return new Variable(a.BOOL == b.BOOL);
                    }
                    else if (op.equals("!="))
                    {
                        return new Variable(a.BOOL != b.BOOL);
                    }
                    else if (op.equals("&&"))
                    {
                        return new Variable(a.BOOL && b.BOOL);
                    }
                    else if (op.equals("||"))
                    {
                        return new Variable(a.BOOL || b.BOOL);
                    }
                }
            }




            Logging.log("Cant do Math: \"" + inBuiltFunctions.executeFunction("string", new Variable[] {a}).STRING + "\" " + op + " \"" + inBuiltFunctions.executeFunction("string", new Variable[] {b}).STRING +"\".", Logging.logtype.script_error);
            return new Variable();
        }

        private static final String regExp = "[\\x00-\\x20]*[+-]?(((((\\p{Digit}+)(\\.)?((\\p{Digit}+)?)([eE][+-]?(\\p{Digit}+))?)|(\\.((\\p{Digit}+))([eE][+-]?(\\p{Digit}+))?)|(((0[xX](\\p{XDigit}+)(\\.)?)|(0[xX](\\p{XDigit}+)?(\\.)(\\p{XDigit}+)))[pP][+-]?(\\p{Digit}+)))[fFdD]?))[\\x00-\\x20]*";
        private static final Pattern pattern = Pattern.compile(regExp);

        public Variable getVarFromValueString(String thing)
        {
            if (thing.startsWith("\"") && thing.endsWith("\"") && thing.length() >= 2) {
                return new Variable(thing.substring(1, thing.length() - 1));
            } else if (thing.toLowerCase().equals("true")) {
                return new Variable(true);
            } else if (thing.toLowerCase().equals("false")) {
                return new Variable(false);
            } else if (thing.matches("-?\\d+")) {
                return new Variable(Integer.parseInt(thing));
            } else if (pattern.matcher(((CharSequence)thing)).matches()) {
                return new Variable(Double.parseDouble(thing));
            } else if (localVars.containsKey(thing)) {
                return localVars.get(thing);
            } else if (globalVars.containsKey(thing)) {
                return globalVars.get(thing);
            } else {
                Logging.log("Could not Parse \"" + thing + "\" into a Variable!", Logging.logtype.script_error);
                return new Variable();
            }
        }

        public Variable getValueFromString(String data)
        {
            List<String> lineSplit = Arrays.asList(splitLine(data, false));


            {
                String temp = "";

                for (int i = 0; i < lineSplit.size(); i++)
                {
                    temp += lineSplit.get(i) + "|";
                }

                //Logging.log("Getting Value from: " + temp, Logging.logtype.script_notification);
            }


            if (lineSplit.size() == 1)
            {
                String thing = lineSplit.get(0);
                    return getVarFromValueString(thing);
            }
            else
            {
                if (lineSplit.size() > 2)
                {
                    if (lineSplit.get(1).equals("(") && lineSplit.get(lineSplit.size() - 1).equals(")")) {
                        String newThing = "";

                        for (int i = 2; i < lineSplit.size() - 1; i++)
                            newThing += lineSplit.get(i);


                        String[] newThingArr = splitLine(newThing, true);

                        List<Variable> args = new ArrayList<>();

                        for (int i = 0; i < newThingArr.length; i++)
                            if (!newThingArr[i].equals(","))
                                args.add(getValueFromString(newThingArr[i]));

                        //Logging.log("Calling Function: " + lineSplit.get(0), Logging.logtype.script_notification);

                        return CallFunctionFromInternal(lineSplit.get(0), args.toArray(new Variable[0]));
                    }
                    else if (lineSplit.get(0).equals("[") && lineSplit.get(lineSplit.size() - 1).equals("]"))
                    {
                        String newThing = "";

                        for (int i = 1; i < lineSplit.size() - 1; i++)
                            newThing += lineSplit.get(i);

                        //System.out.println("Without brackets: " + newThing);

                        String[] newThingArr = splitLine(newThing, true);

                        if (newThingArr.length == 1)
                        {
                            return getValueFromString(newThingArr[0]);
                        }
                        else if (newThingArr.length == 2)
                        {
                            if (newThingArr[0].equals("-"))
                            {
                                return getVarFromValueString("-" + inBuiltFunctions.executeFunction("string", new Variable[] {getValueFromString(newThingArr[1])}).STRING);
                            }
                            if (newThingArr[0].equals("!"))
                            {
                                Variable temp = getValueFromString(newThingArr[1]).clone();
                                temp.BOOL = !temp.BOOL;
                                return temp;
                            }
                        }
                        else
                        {
                            List<Variable> operands = new ArrayList<>();
                            List<String> operators = new ArrayList<>();

                            operands.add(getValueFromString(newThingArr[0]).clone());
                            int index = 1;
                            while(index < newThingArr.length)
                            {
                                operators.add(newThingArr[index]);
                                index++;                                operands.add(getValueFromString(newThingArr[index]).clone());
                                index++;
                            }


                            for (int i = 0; i < operators.size(); i++)
                            {
                                //System.out.println("AAAAAAA: " + operators.get(i));
                                if (operators.get(i).equals("==") || operators.get(i).equals("||") || operators.get(i).equals("&&") || operators.get(i).equals("!=") || operators.get(i).equals(">=") || operators.get(i).equals("<=") || operators.get(i).equals(">") || operators.get(i).equals("<"))
                                {
                                    //System.out.println("AAAAAAAAAAAAAAAAAAAAAAAAAA");
                                    operands.set(i, doMath(operands.get(i), operators.get(i) ,operands.get(i + 1)));
                                    operands.remove(i + 1);
                                    operators.remove(i);
                                    i--;
                                }
                            }
                            for (int i = 0; i < operators.size(); i++)
                            {
                                if (operators.get(i).equals("*") || operators.get(i).equals("/"))
                                {
                                    operands.set(i, doMath(operands.get(i), operators.get(i) ,operands.get(i + 1)));
                                    operands.remove(i + 1);
                                    operators.remove(i);
                                    i--;
                                }
                            }
                            for (int i = 0; i < operators.size(); i++)
                            {
                                if (operators.get(i).equals("+") || operators.get(i).equals("-"))
                                {
                                    operands.set(i, doMath(operands.get(i), operators.get(i) ,operands.get(i + 1)));
                                    operands.remove(i + 1);
                                    operators.remove(i);
                                    i--;
                                }
                            }

                            if (operands.size() == 1)
                                return operands.get(0);
                            else
                                Logging.log("Could not Parse Math expression \"" + data + "\" into a Variable!!!", Logging.logtype.script_error);

                        }

                        Logging.log("Could not Parse Math expression \"" + data + "\" into a Variable!!", Logging.logtype.script_error);
                    } else {
                        Logging.log("Could not Parse Math expression \"" + data + "\" into a Variable!", Logging.logtype.script_error);
                    }
                }
            }



            Logging.log("Could not Parse \"" + data +"\" into a Variable!", Logging.logtype.script_error);
            return new Variable();
        }


        public IFStatement getIFStatementfromLine(int line)
        {
            for (int i = 0; i < ifs.size(); i++)
            {
                IFStatement temp = ifs.get(i);
                if (temp.IFConditionIndex == line || temp.IFStartIndex == line || temp.IFEndIndex == line || temp.ELSEStartIndex == line || temp.ELSEEndIndex == line)
                    return temp;
            }

            return IFStatement.none;
        }

        public WhileStatement getWhileStatementfromLine(int line)
        {
            for (int i = 0; i < whiles.size(); i++)
            {
                WhileStatement temp = whiles.get(i);
                if (temp.startIndex == line || temp.endIndex == line || temp.conditionIndex == line)
                    return temp;
            }

            return WhileStatement.none;
        }



        public Variable execute()
        {
            //Logging.log("Running \"" + func.funcName + "\" Function.", Logging.logtype.script_notification);
            while (index > func.startIndex && index < func.endIndex && !exit)
            {
                String[] lineSplit;

                boolean ignoresemicolon = false;

                if (scriptLines.get(index).startsWith("if") || scriptLines.get(index).startsWith("while"))
                {
                    ignoresemicolon = true;
                }

                if (scriptLines.get(index).equals("}"))
                {
                    ignoresemicolon = true;
                }


                if (scriptLines.get(index).indexOf(';') == -1 && !ignoresemicolon)
                {
                    Logging.log("No Semicolon found at line: " + index + "! (" + scriptLines.get(index) + ")", Logging.logtype.script_error);
                    return new Variable();
                }

                if (scriptLines.get(index).indexOf(';') == -1)
                    lineSplit = splitLine(scriptLines.get(index), true);
                else
                    lineSplit = splitLine(scriptLines.get(index).substring(0, scriptLines.get(index).indexOf(';')), true);

                {
                    String parts = "";

                    for (int i = 0; i < lineSplit.length; i++)
                    {
                        parts += lineSplit[i] + "<|>";
                    }

                    //Logging.log("ARGS: " + parts, Logging.logtype.notification);
                }


                if (lineSplit.length == 1)
                {
                    if (lineSplit[0].contains("(") && lineSplit[0].endsWith(")"))
                    {
                        getValueFromString(lineSplit[0]);
                    }
                    else if (lineSplit[0].equals("return"))
                    {
                        return new Variable(Variable.type.VOID);
                    }
                    else if (lineSplit[0].equals("}"))
                    {
                        {
                            IFStatement current = getIFStatementfromLine(index);
                            if (current.IFConditionIndex != -1)
                            {
                                if (index == current.IFEndIndex)
                                {
                                    index = current.ELSEEndIndex + 1;
                                    continue;
                                }
                                else if (index == current.ELSEEndIndex)
                                {
                                    index++;
                                    continue;
                                }
                            }
                        }
                        {
                            WhileStatement current = getWhileStatementfromLine(index);
                            if (current.conditionIndex != -1)
                            {
                                if (index == current.endIndex)
                                {
                                    String[] lineSplitTemp = splitLine(scriptLines.get(current.conditionIndex), true);


                                    boolean conditionMet = getValueFromString(lineSplitTemp[1]).BOOL;
                                    //System.out.println("WHILE: " + conditionMet);
                                    if (conditionMet)
                                    {
                                        index = current.startIndex + 1;
                                        //System.out.println("IF: " + index);
                                        continue;
                                    }
                                    else
                                    {
                                        index = current.endIndex + 1;
                                        continue;
                                    }
                                }
                            }
                        }

                        Logging.log("NEED TO SKIP ELSE IN CLOSED IF STATEMENT OR IGNORE IF IN ELSE ALREADY", Logging.logtype.script_error);
                    }
                    else if (lineSplit[0].equals("break"))
                    {
                        {
                            int currentLine = index;
                            WhileStatement current = getWhileStatementfromLine(-1);
                            int layer = 1;
                            do {
                                currentLine++;
                                //System.out.println("B " + layer + " A " + i);
                                if (scriptLines.get(currentLine).equals("{"))
                                    layer++;
                                if (scriptLines.get(currentLine).equals("}"))
                                    layer--;

                                //System.out.println("INDEX: " + currentLine + ", LAYER: " + layer + ", LINE: " + scriptLines.get(currentLine));
                                if ((layer == 0) && (currentLine < scriptLines.size()))
                                {
                                    current = getWhileStatementfromLine(currentLine);
                                    if (current.conditionIndex == -1)
                                        layer++;
                                }

                            } while (layer != 0 && (currentLine + 1) < scriptLines.size());

                            if (currentLine < scriptLines.size())
                            {
                                if (current.conditionIndex != -1)
                                {
                                    index = current.endIndex + 1;
                                    continue;
                                }
                                else
                                {
                                    Logging.log("Unable to find the while statement the break statement is referring to!", Logging.logtype.script_error);
                                }
                            }
                            else
                            {
                                Logging.log("Unable to find closing '}' !", Logging.logtype.script_error);
                            }
                        }
                    }
                    else if (lineSplit[0].equals("continue"))
                    {
                        {
                            int currentLine = index;
                            WhileStatement current = getWhileStatementfromLine(-1);
                            int layer = 1;
                            do {
                                currentLine++;
                                //System.out.println("B " + layer + " A " + i);
                                if (scriptLines.get(currentLine).equals("{"))
                                    layer++;
                                if (scriptLines.get(currentLine).equals("}"))
                                    layer--;

                                //System.out.println("INDEX: " + currentLine + ", LAYER: " + layer + ", LINE: " + scriptLines.get(currentLine));
                                if ((layer == 0) && (currentLine < scriptLines.size()))
                                {
                                    current = getWhileStatementfromLine(currentLine);
                                    if (current.conditionIndex == -1)
                                        layer++;
                                }

                            } while (layer != 0 && (currentLine + 1) < scriptLines.size());

                            if (currentLine < scriptLines.size())
                            {
                                if (current.conditionIndex != -1)
                                {
                                    index = current.endIndex;
                                    continue;
                                }
                                else
                                {
                                    Logging.log("Unable to find the while statement the break statement is referring to!", Logging.logtype.script_error);
                                }
                            }
                            else
                            {
                                Logging.log("Unable to find closing '}' !", Logging.logtype.script_error);
                            }
                        }
                    }
                }
                else if (lineSplit.length == 2)
                {
                    if (Variable.parseType(lineSplit[0]) != Variable.type.NONE)
                    {
                        addVar(lineSplit[1], Variable.parseType(lineSplit[0]));
                    }
                    else if (lineSplit[0].equals("return"))
                    {
                        return getValueFromString(lineSplit[1]);
                    }
                    else if (lineSplit[0].equals("if"))
                    {
                        IFStatement current = getIFStatementfromLine(index);
                        if (current.IFConditionIndex != -1)
                        {
                            boolean conditionMet = getValueFromString(lineSplit[1]).BOOL;
                            //System.out.println("IF: " + conditionMet);
                            if (conditionMet)
                            {
                                index = current.IFStartIndex + 1;
                                //System.out.println("IF: " + index);
                                continue;
                            }
                            else
                            {
                                index = current.ELSEStartIndex  + 1;
                                continue;
                            }
                        }
                        else
                        {
                            Logging.log("IF statement not found!", Logging.logtype.script_error);
                        }
                    }
                    else if (lineSplit[0].equals("while"))
                    {
                        WhileStatement current = getWhileStatementfromLine(index);
                        if (current.conditionIndex != -1)
                        {
                            boolean conditionMet = getValueFromString(lineSplit[1]).BOOL;
                            //System.out.println("IF: " + conditionMet);
                            if (conditionMet)
                            {
                                index = current.startIndex + 1;
                                //System.out.println("IF: " + index);
                                continue;
                            }
                            else
                            {
                                index = current.endIndex  + 1;
                                continue;
                            }
                        }
                        else
                        {
                            Logging.log("While statement not found!", Logging.logtype.script_error);
                        }
                    }
                }
                else if(lineSplit.length == 3)
                {
                    if (lineSplit[1].equals("="))
                    {
                        setVar(lineSplit[0], getValueFromString(lineSplit[2]));
                    }
                    else if (lineSplit[1].equals("+") && lineSplit[2].equals("+"))
                    {
                        Variable temp = getVar(lineSplit[0]);
                        if (temp.varType == Variable.type.INT)
                            temp.INT++;
                        if (temp.varType == Variable.type.DOUBLE)
                            temp.DOUBLE++;
                    }
                    else if (lineSplit[1].equals("-") && lineSplit[2].equals("-"))
                    {
                        Variable temp = getVar(lineSplit[0]);
                        if (temp.varType == Variable.type.INT)
                            temp.INT--;
                        if (temp.varType == Variable.type.DOUBLE)
                            temp.DOUBLE--;
                    }
                    else if (lineSplit[0].equals("global") && !Variable.parseType(lineSplit[1]).equals(Variable.type.NONE))
                    {
                        addVar(lineSplit[2], Variable.parseType(lineSplit[1]), true);
                    }
                }
                else if(lineSplit.length == 4)
                {
                    if (Variable.parseType(lineSplit[0]) != Variable.type.NONE)
                    {
                        addVar(lineSplit[1], Variable.parseType(lineSplit[0]));
                        if (lineSplit[2].equals("="))
                        {
                            setVar(lineSplit[1], getValueFromString(lineSplit[3]));
                        }
                    }
                }
                else if(lineSplit.length == 5)
                {
                    if (lineSplit[0].equals("global") && Variable.parseType(lineSplit[1]) != Variable.type.NONE)
                    {
                        addVar(lineSplit[2], Variable.parseType(lineSplit[1]), true);
                        if (lineSplit[3].equals("="))
                        {
                            setVar(lineSplit[2], getValueFromString(lineSplit[4]));
                        }
                    }
                }
                else
                {

                }


                index++;
            }

            return new Variable(Variable.type.VOID);
        }

        public String[] splitLine(String line, boolean combinefunctioncalls)
        {

            List<String> parts = new ArrayList<>();

            String temp = "";

            for (int i = 0; i < line.length(); i++)
            {
                if (line.charAt(i) == '\"')
                {

                    if (!temp.equals("")) {
                        parts.add(temp);
                        temp = "";
                    }
                    i++;
                    while (i < line.length())
                    {

                        if (line.charAt(i) == '\\')
                        {
                            if ((i + 1) < line.length())
                            {
                                if (line.charAt(i + 1) == '\\')
                                {
                                    temp += "\\\\";
                                    i += 2;
                                    continue;
                                }
                                else if (line.charAt(i + 1) == '\"')
                                {
                                    temp += "\\\"";
                                    i += 2;
                                    continue;
                                }
                                else if (line.charAt(i + 1) == 'n')
                                {
                                    temp += "\\n";
                                    i += 2;
                                    continue;
                                }
                                else
                                {
                                    Logging.log("Invalid String Escape Sequence! (line: " + line + ").", Logging.logtype.script_error);
                                    break;
                                }
                            }
                            else
                            {
                                Logging.log("String Escape Sequence not ended! (line: " + line + ").", Logging.logtype.script_error);
                                break;
                            }
                        }
                        else if (line.charAt(i) == '\"')
                        {
                            break;
                        }

                        temp += line.charAt(i);
                        i++;
                    }

                    parts.add("\"" + temp + "\"");
                    temp = "";


                    continue;
                }
                else if (line.charAt(i) == ' ')
                {
                    if (!temp.equals("")) {
                        parts.add(temp);
                        temp = "";
                    }
                    continue;
                }
                else if ((i + 1) < line.length())
                {
                    if (line.charAt(i) == '=' && line.charAt(i + 1) == '=')
                    {
                        if (!temp.equals("")) {
                            parts.add(temp);
                            temp = "";
                        }
                        parts.add("==");
                        i++;
                        continue;
                    }
                    else if (line.charAt(i) == '!' && line.charAt(i + 1) == '=')
                    {
                        if (!temp.equals("")) {
                            parts.add(temp);
                            temp = "";
                        }
                        parts.add("!=");
                        i++;
                        continue;
                    }
                    else if (line.charAt(i) == '>' && line.charAt(i + 1) == '=')
                    {
                        if (!temp.equals("")) {
                            parts.add(temp);
                            temp = "";
                        }
                        parts.add(">=");
                        i++;
                        continue;
                    }
                    else if (line.charAt(i) == '<' && line.charAt(i + 1) == '=')
                    {
                        if (!temp.equals("")) {
                            parts.add(temp);
                            temp = "";
                        }
                        parts.add("<=");
                        i++;
                        continue;
                    }
                    else if (line.charAt(i) == '|' && line.charAt(i + 1) == '|')
                    {
                        if (!temp.equals("")) {
                            parts.add(temp);
                            temp = "";
                        }
                        parts.add("||");
                        i++;
                        continue;
                    }
                    else if (line.charAt(i) == '&' && line.charAt(i + 1) == '&')
                    {
                        if (!temp.equals("")) {
                            parts.add(temp);
                            temp = "";
                        }
                        parts.add("&&");
                        i++;
                        continue;
                    }
                }
                if ("<>(),+-*/[]!".contains((CharSequence)(line.charAt(i) + "")))
                {
                    if (!temp.equals("")) {
                        parts.add(temp);
                        temp = "";
                    }
                    parts.add(line.charAt(i) + "");
                    continue;
                }

                temp += line.charAt(i);
            }
            if (!temp.equals("")) {
                parts.add(temp);
            }


            if (combinefunctioncalls)
            {
                for (int i = 0; i < parts.size(); i++)
                {
                    if (parts.get(i).equals("("))
                    {
                        parts.set(i - 1, parts.get(i-1) + parts.get(i));
                        parts.remove(i);
                        int layer = 1;
                        while (i < parts.size() && layer != 0)
                        {
                            if (parts.get(i).equals("("))
                                layer++;
                            if (parts.get(i).equals(")"))
                                layer--;

                            parts.set(i - 1, parts.get(i-1) + parts.get(i));
                            parts.remove(i);
                        }

                    }
                }
                for (int i = 0; i < parts.size(); i++)
                {
                    if (parts.get(i).equals("["))
                    {
                        i++;
                        //parts.set(i - 1, parts.get(i-1) + parts.get(i));
                        //parts.remove(i);
                        int layer = 1;
                        while (i < parts.size() && layer != 0)
                        {
                            if (parts.get(i).equals("["))
                                layer++;
                            if (parts.get(i).equals("]"))
                                layer--;

                            parts.set(i - 1, parts.get(i-1) + parts.get(i));
                            parts.remove(i);
                        }

                    }
                }
            }




            return parts.toArray(new String[0]);
        }

        public void run() {
            execute();
        }

        public void start () {
            //System.out.println("Starting " +  threadName );
            if (t == null) {
                t = new Thread (this);
                t.start ();
            }
        }
    }
}


class IFStatement
{
    public int IFStartIndex, IFEndIndex, ELSEStartIndex, ELSEEndIndex, IFConditionIndex;

    public IFStatement(int IFStartIndex, int IFEndIndex, int ELSEStartIndex, int ELSEEndIndex, int IFConditionIndex)
    {
        this.IFStartIndex = IFStartIndex;
        this.IFEndIndex = IFEndIndex;
        this.ELSEStartIndex = ELSEStartIndex;
        this.ELSEEndIndex = ELSEEndIndex;
        this.IFConditionIndex = IFConditionIndex;

        //Logging.log("Created IF Statement at line: " + IFConditionIndex + ". (IF: " + IFStartIndex + " - " + IFEndIndex + ", ELSE:" + ELSEStartIndex + " - " + ELSEEndIndex + ")", Logging.logtype.script_notification);
    }

    public static final IFStatement none = new IFStatement(-1, -1, -1, -1, -1);
}

class WhileStatement
{
    public int startIndex, endIndex, conditionIndex;

    public WhileStatement(int startIndex, int endIndex, int conditionIndex)
    {
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.conditionIndex = conditionIndex;

        //Logging.log("Created While Statement at line:" + conditionIndex + ". (" + startIndex + " - " + endIndex + ")", Logging.logtype.script_notification);
    }

    public static final WhileStatement none = new WhileStatement(-1,-1,-1);
}


class Function
{
    public int startIndex, endIndex;
    public String funcName;
    public List<String> funcArgumentNames;
    public List<Variable.type> funcArgumentVars;
    public Variable.type returnType;


    public Function(String funcName, int startIndex, int endIndex, List<String> funcArgumentNames, List<Variable.type> funcArgumentVars, Variable.type returnType)
    {
        this.startIndex = startIndex;
        this.endIndex = endIndex;
        this.funcName = funcName;
        this.funcArgumentNames = funcArgumentNames;
        this.funcArgumentVars = funcArgumentVars;

        //Logging.log("Created Function \"" + funcName + "\". (" + startIndex + " - " + endIndex + ") Return Type: " + returnType + ".", Logging.logtype.script_notification);

        for (int i = 0; i < funcArgumentNames.size(); i++)
        {
            //Logging.log(" - Variable \"" + funcArgumentNames.get(i) +"\" (type: " + funcArgumentVars.get(i) + ").", Logging.logtype.script_notification);
        }





    }

}

class ListThing
{
    public List<Variable> list;
    public ListThing()
    {
        list = new ArrayList<>();
    }
}

class NetworkThing
{
    public MainAcceptThread client;
    public String ip;
    public NetworkThing(String ip, MainAcceptThread client)
    {
        this.ip = ip;
        this.client = client;
    }

    public boolean send(String data)
    {
        //Logging.log("SENDING NOT IMPLEMENTED", Logging.logtype.error);
        if (client != null)
        {
            if (true)
            {
                client.send(data);
                return true;
            }
        }
        return false;
    }

    public String receive()
    {
        //Logging.log("RECEIVING NOT IMPLEMENTED!", Logging.logtype.error);
        return client.receive();
    }

    public void close()
    {
        client.close();
    }
}


class Variable
{
    public type varType;

    public String STRING;
    public int INT;
    public boolean BOOL;
    public double DOUBLE;

    public Variable clone()
    {
        Variable temp = new Variable();
        temp.varType = this.varType;
        temp.STRING = this.STRING;
        temp.INT = this.INT;
        temp.BOOL = this.BOOL;
        temp.DOUBLE = this.DOUBLE;
        return temp;
    }

    public Variable(String data)
    {
        StringBuilder temp2 = new StringBuilder();

        for (int i = 0; i < data.length(); i++)
        {
            if (data.charAt(i) == '\\')
            {
                if (i + 1 < data.length())
                {
                    if (data.charAt(i + 1) == '\\')
                    {
                        temp2.append('\\');
                        i += 1;
                        continue;
                    }
                    else if (data.charAt(i + 1) == '\"')
                    {
                        temp2.append('\"');
                        i += 1;
                        continue;
                    }
                    else if (data.charAt(i + 1) == 'n')
                    {
                        temp2.append('\n');
                        i += 1;
                        continue;
                    }
                }
                else
                    Logging.log("Invalid Escape Sequence", Logging.logtype.script_error);
            }
            temp2.append(data.charAt(i));
        }
        STRING = temp2.toString();
        varType = type.STRING;
    }
    public Variable(int data)
    {
        INT = data;
        varType = type.INT;
    }
    public Variable(double data)
    {
        DOUBLE = data;
        varType = type.DOUBLE;
    }
    public Variable(boolean data)
    {
        BOOL = data;
        varType = type.BOOL;
    }
    public Variable()
    {
        varType = type.VOID;
    }
    public Variable(type varType)
    {
        this.varType = varType;
    }


    public enum type
    {
        INT,
        DOUBLE,
        BOOL,
        STRING,
        VOID,
        NONE
    }

    public static type parseType(String data)
    {
        if (data.toLowerCase().equals("int"))
            return type.INT;
        else if (data.toLowerCase().equals("double"))
            return type.DOUBLE;
        else if (data.toLowerCase().equals("bool"))
            return type.BOOL;
        else if (data.toLowerCase().equals("string"))
            return type.STRING;
        else if (data.toLowerCase().equals("void"))
            return type.VOID;
        else
            return type.NONE;
    }
}