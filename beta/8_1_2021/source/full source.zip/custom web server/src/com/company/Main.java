package com.company;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

import static java.lang.System.exit;

public class Main {

    public static String userInput;
    public static String serverFolderName;
    public static String mainScript;
    public static String ip;
    public static int port;




    public static void main(String[] args) {

        Logging.init();

        new MainInputThread().start();

        Logging.log("Reading config file...", Logging.logtype.notification);
        initProperties();
        readProperties("config.cfg");

        Logging.log("Properties:", Logging.logtype.normal);
        Logging.log("- IP: " + ip, Logging.logtype.normal);
        Logging.log("- Port: " + port, Logging.logtype.normal);
        Logging.log("- Main Folder: " + serverFolderName, Logging.logtype.normal);
        Logging.log("- Main Script: " + mainScript, Logging.logtype.normal);

        ScriptInterpreterManager.init();
        if (!mainScript.equals(""))
        {
            ScriptInterpreterManager.addScript(mainScript, true);
        }

        Logging.log("Starting Web Server.", Logging.logtype.notification);
        TCP_Server.listeningTest();

    }

    public static void initProperties()
    {
        serverFolderName = "testing";
        mainScript = "";
        ip = "localhost";
        port = 1234;

    }

    public static void setProperty(String name, String value)
    {
        if (name.equals("IP"))
            ip = value;
        else if (name.equals("Port"))
            port = Integer.parseInt(value);
        else if (name.equals("Site_folder"))
            serverFolderName = value;
        else if (name.equals("Main_script"))
            mainScript = value;


    }

    public static void readProperties(String file)
    {
        try(BufferedReader br = new BufferedReader(new FileReader(file))) {
            for(String line; (line = br.readLine()) != null; ) {
                if (!line.equals(""))
                {
                    if (line.indexOf(':') != -1)
                    {
                        String[] temp = line.split(java.util.regex.Matcher.quoteReplacement(":"));
                        String name = temp[0].trim();
                        String value = temp[1].trim();
                        setProperty(name, value);
                    }
                }
            }
            // line is not visible here.
        } catch (FileNotFoundException e) {
            Logging.log("File not found!", Logging.logtype.error);
            exit(-1);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}




class MainInputThread extends Thread {
    public void run() {
        Scanner consoleInput = new Scanner(System.in);
        while(true)
        {
            Main.userInput = consoleInput.next();
            //System.out.println("input: " + Main.userInput);
        }
    }
}

